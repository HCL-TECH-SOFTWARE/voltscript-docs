{
  "classes": [
    {
      "class_methods": [
        {
          "description": "This method will compare two JSON objects based on the labels provided.",
          "name": "Compare",
          "parameters": [
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "src",
              "type": "Variant"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "tgt",
              "type": "Variant"
            }
          ],
          "returnType": "Integer",
          "type": "Function"
        },
        {
          "description": "This class is used by the jsonSort class to compare two JSON objects based on the labels and sort orders provided.",
          "name": "New",
          "parameters": [
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "isDescending",
              "type": "Boolean"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "jlabelobj",
              "type": "jsonSortLabels"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "This class is used by the jsonSort class to compare two JSON objects based on the labels and sort orders provided.",
      "name": "jsonComparator",
      "namespace": "VoltMXObjects"
    },
    {
      "class_methods": [
        {
          "description": "Simple method to set the labels, sort order, and delimiter",
          "name": "setLabels",
          "parameters": [
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "label1",
              "type": "String"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "label1IsDesc",
              "type": "Boolean"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "label2",
              "type": "String"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "label2IsDesc",
              "type": "Boolean"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "label3",
              "type": "String"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "label3IsDesc",
              "type": "Boolean"
            },
            {
              "description": "",
              "isbyval": "False",
              "islist": "False",
              "name": "delim",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "This class is used to store the labels, sort order, and delimiter for the jsonSort class. The class is used by the jsonSort class to sort the JSON objects.",
      "name": "jsonSortLabels",
      "namespace": "VoltMXObjects"
    },
    {
      "class_methods": [
        {
          "description": "Adds an input parameter for the Foundry integration service. This proxies the corresponding function in VotMxResult object. Only relevant for preprocessors.",
          "name": "addInputParam",
          "parameters": [
            {
              "description": "Key for the input parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the input parameter. This should be a scalar.",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds a request parameter to the Foundry request. This proxies the corresponding method in VoltMxResult. Only relevant for preprocessors.",
          "name": "addRequestParam",
          "parameters": [
            {
              "description": "Key for the request parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the request parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Gets a header parameter from the Foundry request.",
          "name": "getHeaderParam",
          "parameters": [
            {
              "description": "Key for the header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Gets a parameter from the JWT token for an identity service associated with this integration service, or an empty string if no identity service is assigned to this integration service.",
          "name": "getIdentityParam",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets an input parameter passed to Foundry.",
          "name": "getInputParam",
          "parameters": [
            {
              "description": "Key for the input parameter. Keys are case-sensitive",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Gets a Foundry request parameter. These are parameters like appID, used for internal Foundry processing. This is not for input parameters defined in the Foundry integration service mapping.",
          "name": "getRequestParam",
          "parameters": [
            {
              "description": "Key for the request parameter. Keys are case-sensitive",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor. This is automatically called during extractObjects() and should not be run manually.",
          "name": "New",
          "parameters": [
            {
              "description": "Result object that will be passed back to Foundry",
              "isbyval": "False",
              "islist": "False",
              "name": "result",
              "type": "VoltMxResultObject"
            },
            {
              "description": "JsonObject of input parameters for the integration service",
              "isbyval": "False",
              "islist": "False",
              "name": "serviceInputParams",
              "type": "JsonObject"
            },
            {
              "description": "JsonObject of identity parameter (or Nothing) for the integration service",
              "isbyval": "False",
              "islist": "False",
              "name": "identityParam",
              "type": "JsonObject"
            },
            {
              "description": "JsonObject containing the Foundry request",
              "isbyval": "False",
              "islist": "False",
              "name": "jsonObj",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class for interacting with Foundry request.",
      "name": "VoltMxRequestObject",
      "namespace": "VoltMXObjects"
    },
    {
      "class_methods": [
        {
          "description": "Adds a device header parameter for the Foundry response. This proxies the corresponding method in VoltMxResult object.",
          "name": "addDeviceHeaderParam",
          "parameters": [
            {
              "description": "Key of the device header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "String value of the device header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds a header param to the Foundry response. This proxies the corresponding method in VoltMxResult object.",
          "name": "addHeaderParam",
          "parameters": [
            {
              "description": "Key for the Foundry response parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the Foundry response parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Gets a device header parameter for the Foundry response.",
          "name": "getDeviceHeaderParam",
          "parameters": [
            {
              "description": "Key for the device header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets a header parameter from the Foundry response. This is only relevant for postprocessors.",
          "name": "getHeaderParam",
          "parameters": [
            {
              "description": "Key for the header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Gets the status code of the Foundry response. This is only relevant for postprocessors.",
          "name": "getStatusCode",
          "parameters": [],
          "returnType": "Integer",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "description": "Result object that will be passed back to Foundry",
              "isbyval": "False",
              "islist": "False",
              "name": "result",
              "type": "VoltMxResultObject"
            },
            {
              "description": "JsonObject containing the Foundry response object",
              "isbyval": "False",
              "islist": "False",
              "name": "jsonObj",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class for interacting with Volt MX response.",
      "name": "VoltMxResponseObject",
      "namespace": "VoltMXObjects"
    },
    {
      "class_methods": [
        {
          "description": "Adds a message to be debugged from Foundry's Java logger.",
          "name": "addDebugMessage",
          "parameters": [
            {
              "description": "Message to debug",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds a device header parameter for the Foundry response.",
          "name": "addDeviceHeaderParam",
          "parameters": [
            {
              "description": "Key of the device header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "String value for the device header parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds a header param to the Foundry response.",
          "name": "addHeaderParam",
          "parameters": [
            {
              "description": "Key for the Foundry response parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the Foundry response parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds an input parameter for the Foundry integration service. This is only relevant for preprocessors.",
          "name": "addInputParam",
          "parameters": [
            {
              "description": "Key for the input parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the input parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds a request parameter to the Foundry request. Only relevant for preprocessors.",
          "name": "addRequestParam",
          "parameters": [
            {
              "description": "Key for the request parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the request parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Adds a session attribute for the Foundry session object.",
          "name": "addSessionAttribute",
          "parameters": [
            {
              "description": "Key for the session attribute",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the session attribute",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Copies the incoming unit test context for VoltScript HTTP server into the result, the unitTestContext element outputed by setting \"vsTestingContext\":true in integration services.",
          "name": "echoHttpServerContext",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Copies the incoming unit test context for VoltScript HTTP server into the result, the unitTestContext element outputed by setting \"vsTestingContext\":true in integration services.",
          "name": "echoUnitTestContext",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "",
          "name": "loadFromJson",
          "parameters": [
            {
              "description": "JSON object containing the incoming result",
              "isbyval": "False",
              "islist": "False",
              "name": "jsonObj",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Constructor. This is automatically called during extractObjects() and should not be run manually.",
          "name": "New",
          "parameters": [
            {
              "description": "Whether the VoltScript is being called from a preprocessor",
              "isbyval": "False",
              "islist": "False",
              "name": "isPreProcessor",
              "type": "Boolean"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Sets an error message to pass back to Foundry. Only a single string error message can be passed back.",
          "name": "setErrorMessage",
          "parameters": [
            {
              "description": "Error message to send back to the browser",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Converts the VoltMxResultObject into JSON for passing back to Foundry'",
          "name": "toJson",
          "parameters": [],
          "returnType": "JsonObject",
          "type": "Function"
        }
      ],
      "class_properties": [
        {
          "default": "0",
          "description": "HTTP status code that will be returned from the integration service.",
          "name": "httpStatusCode",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "0",
          "description": "Opstatus that will be returned from the integration service.",
          "name": "opstatus",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "JsonObject that will be outputted from the integration service",
          "name": "result",
          "parameters": [],
          "type": "JsonObject"
        }
      ],
      "class_variables": [],
      "description": "Class for passing content back to Foundry and manipulating results from an integration service in its postprocessor.",
      "name": "VoltMxResultObject",
      "namespace": "VoltMXObjects"
    },
    {
      "class_methods": [
        {
          "description": "Adds a session attribute to the Foundry session.",
          "name": "addAttribute",
          "parameters": [
            {
              "description": "Key for the session attribute",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            },
            {
              "description": "Value for the session attribute. This should be a scalar.",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Retrieves a session attribute that has been set in a prior request or via setAttribute().",
          "name": "getAttribute",
          "parameters": [
            {
              "description": "Key of the attribute",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor. This is automatically called during extractObjects() and should not be run manually.",
          "name": "New",
          "parameters": [
            {
              "description": "Result object that will be passed back to Foundry",
              "isbyval": "False",
              "islist": "False",
              "name": "result",
              "type": "VoltMxResultObject"
            },
            {
              "description": "JsonObject containing cookies",
              "isbyval": "False",
              "islist": "False",
              "name": "jsonObj",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [
        {
          "attribute": "",
          "default": "",
          "description": "Collection of session cookies.",
          "name": "cookies",
          "type": "Collection"
        }
      ],
      "description": "Class for interacting with Foundry session content.",
      "name": "VoltMxSessionObject",
      "namespace": "VoltMXObjects"
    }
  ],
  "description": "Implement with USE <libs dir>/\"VoltMXObjects\"",
  "methods": [
    {
      "description": "",
      "name": "extractObjects",
      "parameters": [
        {
          "description": "JSON string input from Foundry",
          "isbyval": "False",
          "islist": "False",
          "name": "data",
          "type": "String"
        },
        {
          "description": "Whether Foundry object is from a preprocessor",
          "isbyval": "False",
          "islist": "False",
          "name": "isPreprocessor",
          "type": "Boolean"
        }
      ],
      "returnType": "",
      "type": "Sub"
    },
    {
      "description": "Converts an Error object to error code, message, line and stack trace",
      "name": "getErrorMsg",
      "parameters": [
        {
          "description": "Prefix to prepend to the outputted error message",
          "isbyval": "False",
          "islist": "False",
          "name": "prefix",
          "type": "String"
        }
      ],
      "returnType": "String",
      "type": "Function"
    },
    {
      "description": "Given an array of JSON objects, returns a sorted array of JSON objects. Uses VoltScript Collections internally as a dependency.",
      "name": "jsonSort",
      "parameters": [
        {
          "description": "JSON Object to be sorted",
          "isbyval": "False",
          "islist": "False",
          "name": "dataObj",
          "type": "JsonObject"
        },
        {
          "description": "First label on which to sort",
          "isbyval": "False",
          "islist": "False",
          "name": "lbl1",
          "type": "String"
        },
        {
          "description": "True if the first sort should be Descending, False if Ascending",
          "isbyval": "False",
          "islist": "False",
          "name": "lbl1Desc",
          "type": "Boolean"
        },
        {
          "description": "Second label on which to sort. Optional.",
          "isbyval": "False",
          "islist": "False",
          "name": "lbl2",
          "type": "String"
        },
        {
          "description": "True if the second sort should be Descending, False if Ascending",
          "isbyval": "False",
          "islist": "False",
          "name": "lbl2Desc",
          "type": "Boolean"
        },
        {
          "description": "Third label on which to sort. Optional.",
          "isbyval": "False",
          "islist": "False",
          "name": "lbl3",
          "type": "String"
        },
        {
          "description": "True if the third sort should be Descending, False if Ascending",
          "isbyval": "False",
          "islist": "False",
          "name": "lbl3Desc",
          "type": "Boolean"
        },
        {
          "description": "The delimiter used by label paths. If not provided, delim will default to \"/\"",
          "isbyval": "False",
          "islist": "False",
          "name": "delim",
          "type": "String"
        }
      ],
      "returnType": "JsonObject",
      "type": "Function"
    }
  ],
  "name": "VoltMXObjects",
  "properties": [],
  "types": [],
  "variables": [
    {
      "attribute": "",
      "default": "\"\"",
      "description": "Main directory of the project, required because CurDir returns the VoltScript program directory. Use this to retrieve resource files within the project directory, and set manually for unit tests.",
      "name": "PROJECT_DIR",
      "type": "String"
    },
    {
      "attribute": "",
      "default": "",
      "description": "Instance of VoltMxRequestObject parsed from Foundry input by extractObjects.",
      "name": "VoltMxRequest",
      "type": "VoltMxRequestObject"
    },
    {
      "attribute": "",
      "default": "",
      "description": "Instance of VoltMxResponseObject parsed from Foundry input by extractObjects.",
      "name": "VoltMxResponse",
      "type": "VoltMxResponseObject"
    },
    {
      "attribute": "",
      "default": "",
      "description": "Instance of VoltMxResultObject parsed from Foundry input by extractObjects.",
      "name": "VoltMxResult",
      "type": "VoltMxResultObject"
    },
    {
      "attribute": "",
      "default": "",
      "description": "Instance of VoltMxSessionObject parsed from Foundry input by extractObjects.",
      "name": "VoltMxSession",
      "type": "VoltMxSessionObject"
    }
  ]
}
