{
  "classes": [
    {
      "class_methods": [
        {
          "description": "Adds an element to the container",
          "name": "add",
          "parameters": [
            {
              "description": "Must match Collection's ContentType",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Long",
          "type": "Function"
        },
        {
          "description": "Adds all elements from an array or source Collection to the current Collection.",
          "name": "addAll",
          "parameters": [
            {
              "description": "Variant array or Collection of elements matching the Collection's ContentType",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Collection",
          "type": "Function"
        },
        {
          "description": "Removes all values from the Collection and resets whether the collection is reversed.",
          "name": "clear",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Creates a copy of the Collection",
          "name": "clone",
          "parameters": [],
          "returnType": "Collection",
          "type": "Function"
        },
        {
          "description": "Checks whether the Collection contains a specific value. Requires a valid Comparator to compare each element.",
          "name": "contains",
          "parameters": [
            {
              "description": "Value to check for",
              "isbyval": "False",
              "islist": "False",
              "name": "checkValue",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Filters a collection using a CollectionFilter and returns a new \"filtered\" collection",
          "name": "filter",
          "parameters": [
            {
              "description": "Collection filter to check each value with",
              "isbyval": "False",
              "islist": "False",
              "name": "filterObj",
              "type": "CollectionFilter"
            }
          ],
          "returnType": "Collection",
          "type": "Function"
        },
        {
          "description": "Loads the scalar values array from the JsonObject into the Collection. Can only be used for a JsonObject that contains a single array of scalars.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JsonObject containig an array of scalars",
              "isbyval": "False",
              "islist": "False",
              "name": "jsonObj",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Returns the FIRST element in the collection and removes it from the collection.",
          "name": "getAndRemoveFirstRaw",
          "parameters": [],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Returns the LAST element in the collection and removes it from the collection.",
          "name": "getAndRemoveLastRaw",
          "parameters": [],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Checks whether the Collection contains a specific value.",
          "name": "getIndex",
          "parameters": [
            {
              "description": "Value to check for",
              "isbyval": "False",
              "islist": "False",
              "name": "checkValue",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Gets the nth elment as a raew variant, starting at index 0",
          "name": "getNthElementRaw",
          "parameters": [
            {
              "description": "Index of the element to return",
              "isbyval": "False",
              "islist": "False",
              "name": "index",
              "type": "Long"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Inserts an element in the collection at an index, starting at index 0. Not allowed for sorted collections",
          "name": "insertAt",
          "parameters": [
            {
              "description": "Must match Collection's ContentType",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Index at which to insert the element",
              "isbyval": "False",
              "islist": "False",
              "name": "index",
              "type": "Long"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Joins a collection of scalar values into a single string response separated by a passed delimiter",
          "name": "join",
          "parameters": [
            {
              "description": "Delimiter to separate values",
              "isbyval": "False",
              "islist": "False",
              "name": "delim",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Locks the collection, so any add, remove, replace or reverse functions trigger errors. ",
          "name": "lock",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "description": "Defines the Content Type of the Collection",
              "isbyval": "False",
              "islist": "False",
              "name": "contentType",
              "type": "String"
            },
            {
              "description": "Comparator instance to use when checking for unique and sorting elements. If Nothing is passed, a default Comparator will be used which works for scalars, grouping numbers and comparing on data type and value",
              "isbyval": "False",
              "islist": "False",
              "name": "comparator",
              "type": "Comparator"
            },
            {
              "description": "Flag indicating if elements within the Collection must be unique",
              "isbyval": "False",
              "islist": "False",
              "name": "mustBeUnique",
              "type": "Boolean"
            },
            {
              "description": "Flag indicating if the content within the Collection shall be sorted",
              "isbyval": "False",
              "islist": "False",
              "name": "isSorted",
              "type": "Boolean"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Removes an element (or elements, if not unique) from the Collection. Returns the number of elements removed.",
          "name": "remove",
          "parameters": [
            {
              "description": "Element to remove",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Whether to remove all elements that match source or just the first match",
              "isbyval": "False",
              "islist": "False",
              "name": "allMatches",
              "type": "Boolean"
            }
          ],
          "returnType": "Long",
          "type": "Function"
        },
        {
          "description": "Replaces an element with another and returns the number of replacements made.",
          "name": "replace",
          "parameters": [
            {
              "description": "Value to replace",
              "isbyval": "False",
              "islist": "False",
              "name": "oldValue",
              "type": "Variant"
            },
            {
              "description": "Value to insert",
              "isbyval": "False",
              "islist": "False",
              "name": "newValue",
              "type": "Variant"
            },
            {
              "description": "Whether to replace the first match or all matches",
              "isbyval": "False",
              "islist": "False",
              "name": "allMatches",
              "type": "Boolean"
            }
          ],
          "returnType": "Long",
          "type": "Function"
        },
        {
          "description": "Reverses a collection",
          "name": "reverse",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Converts the Collection to a JsonObject that's an array.",
          "name": "toJson",
          "parameters": [],
          "returnType": "JsonObject",
          "type": "Function"
        },
        {
          "description": "Transforms members of this Collection using a CollectionTransformer and adds them to the new Collection passed",
          "name": "transform",
          "parameters": [
            {
              "description": "CollectionTransformer to transform members",
              "isbyval": "False",
              "islist": "False",
              "name": "transformer",
              "type": "CollectionTransformer"
            },
            {
              "description": "Collection to load transformed members into",
              "isbyval": "False",
              "islist": "False",
              "name": "newColl",
              "type": "Collection"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Unlocks the Collection, so add, remove, replace or reverse functions can be used again",
          "name": "unlock",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "Comparator to compare values with",
          "name": "comparator",
          "parameters": [],
          "type": "Comparator"
        },
        {
          "default": "",
          "description": "TypeName(s) of elements within the Collection",
          "name": "contentType",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Number of elements within the Collection",
          "name": "elementCount",
          "parameters": [],
          "type": "Long"
        },
        {
          "default": "",
          "description": "Flag indicating if the Collection has elemens",
          "name": "hasContent",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flag indicating if the Collection is locked, so adds, removes and replaces are aborted",
          "name": "isLocked",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flagindicating whether the Collection has been reversed",
          "name": "isReversed",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flag indicating if the Collection is sorted (using Comparator object internally)",
          "name": "isSorted",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flag indicating if the elements in the Collection must be unique",
          "name": "isUnique",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Suppress errors on adding elements. Errors wll still be thrown if the Collection is locked",
          "name": "suppressErrors",
          "parameters": [],
          "type": "Boolean"
        }
      ],
      "class_variables": [],
      "description": "Base class for Collections",
      "name": "Collection",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "Function to filter an element \"in\" or \"out\" of the resulting collection",
          "name": "filter",
          "parameters": [
            {
              "description": "True to filter the value *in*, False to filter *out*",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class for filtering elements when filtering a Collection",
      "name": "CollectionFilter",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Function to transform a member of a Collection. If there is no return value, the element is skipped and nothing gets added to the new Collection for this element. Thus the function can perform a filter and a transform simultaneously.",
          "name": "transform",
          "parameters": [
            {
              "description": "Value to transform",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class to transform elements in a Collection to something else",
      "name": "CollectionTransformer",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "Main function that does the comparison. Only needs to code for natural before/after. The outer function will reverse the result if the Comparator is instantiated as descending order or Collection has been reversed.",
          "name": "compare",
          "parameters": [
            {
              "description": "Element being inserted",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Element at current position",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "Variant"
            }
          ],
          "returnType": "Integer",
          "type": "Function"
        },
        {
          "description": "Compares source and target, returning -1 if source is before target, 0 if they are the same, 1 if source is after target.",
          "name": "compareAscDesc",
          "parameters": [
            {
              "description": "Element being inserted",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Element at current position",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "Variant"
            },
            {
              "description": "Whether the parent Collection is reversed",
              "isbyval": "False",
              "islist": "False",
              "name": "collReversed",
              "type": "Boolean"
            }
          ],
          "returnType": "Integer",
          "type": "Function"
        },
        {
          "description": "Function to determine if two values are determined to be identical.",
          "name": "equals",
          "parameters": [
            {
              "description": "Element being inserted",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Element at current position",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [
            {
              "description": "Whether sorting should be in descending order",
              "isbyval": "False",
              "islist": "False",
              "name": "isDescending",
              "type": "Boolean"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "",
          "name": "isDescending",
          "parameters": [],
          "type": "Boolean"
        }
      ],
      "class_variables": [],
      "description": "Class used to handle comparison logic (used primarily for sorting Collection objects)",
      "name": "Comparator",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "Removes all keys and values from the Map and resets whether the keyset is reversed.",
          "name": "clear",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Creates a clone of the Map.",
          "name": "clone",
          "parameters": [],
          "returnType": "Map",
          "type": "Function"
        },
        {
          "description": "Returns a clone of the keys in this Map.",
          "name": "collectKeys",
          "parameters": [],
          "returnType": "Collection",
          "type": "Function"
        },
        {
          "description": "Loads the values from this Map into the passed Collection.",
          "name": "collectValues",
          "parameters": [
            {
              "description": "Collection into which to add the values from this Map",
              "isbyval": "False",
              "islist": "False",
              "name": "targetColl",
              "type": "Collection"
            }
          ],
          "returnType": "Collection",
          "type": "Function"
        },
        {
          "description": "Checks whether the Map contains a specific value.",
          "name": "contains",
          "parameters": [
            {
              "description": "Value to check for",
              "isbyval": "False",
              "islist": "False",
              "name": "checkValue",
              "type": "Variant"
            },
            {
              "description": "Comparator to use to check vale",
              "isbyval": "False",
              "islist": "False",
              "name": "valueComparator",
              "type": "Comparator"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks whether the Map contains a specific key.",
          "name": "containsKey",
          "parameters": [
            {
              "description": "Value to check for",
              "isbyval": "False",
              "islist": "False",
              "name": "keyVal",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Filters a Map using a mapFilter and returns a new \"filtered\" Map.",
          "name": "filter",
          "parameters": [
            {
              "description": "Map filter to check each key and value with",
              "isbyval": "False",
              "islist": "False",
              "name": "filterObj",
              "type": "MapFilter"
            }
          ],
          "returnType": "Map",
          "type": "Function"
        },
        {
          "description": "Loads a JsonObject that contains an object of scalars into the Map",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JsonObject to put in the map",
              "isbyval": "False",
              "islist": "False",
              "name": "jsonObj",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Gets and removes the first key/value Pair.",
          "name": "getAndRemoveFirstPair",
          "parameters": [],
          "returnType": "Pair",
          "type": "Function"
        },
        {
          "description": "Gets and removes the last key/value Pair",
          "name": "getAndRemoveLastPair",
          "parameters": [],
          "returnType": "Pair",
          "type": "Function"
        },
        {
          "description": "Returns the key at a particular index",
          "name": "getNthKeyRaw",
          "parameters": [
            {
              "description": "Index of key to get, starting at 0",
              "isbyval": "False",
              "islist": "False",
              "name": "index",
              "type": "Long"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Returns the element at the relevant index as a key/value Pair",
          "name": "getNthPair",
          "parameters": [
            {
              "description": "Index at which to find the element",
              "isbyval": "False",
              "islist": "False",
              "name": "index",
              "type": "Long"
            }
          ],
          "returnType": "Pair",
          "type": "Function"
        },
        {
          "description": "Gets the value at a particular index. If no matching value is found, the return type will depend on the content defined. If the Map contains objects, the return value is Nothing. If the Map contains scalars, the return value is an empty variant.",
          "name": "getNthValueRaw",
          "parameters": [
            {
              "description": "Index of the value to get, starting at 0",
              "isbyval": "False",
              "islist": "False",
              "name": "index",
              "type": "Long"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Gets a value from the Map for the passed key. If the Map contains objects, the return type is Nothing.",
          "name": "getValueRawByKey",
          "parameters": [
            {
              "description": "Key of value to get",
              "isbyval": "False",
              "islist": "False",
              "name": "keyVal",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Locks the map, so any put, remove, replace or reverse fiunctions trigger errors. Useful when passing a Map to other functions.",
          "name": "lock",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "description": "Defines the Content Type of the values in the Map",
              "isbyval": "False",
              "islist": "False",
              "name": "contentType",
              "type": "String"
            },
            {
              "description": "Comparator to determine order of keys",
              "isbyval": "False",
              "islist": "False",
              "name": "keyComparator",
              "type": "Comparator"
            },
            {
              "description": "Flag indicating if the keys within the Map shall be sorted",
              "isbyval": "False",
              "islist": "False",
              "name": "isSorted",
              "type": "Boolean"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Puta an element in the Map.",
          "name": "put",
          "parameters": [
            {
              "description": "Scalar value to use as the key",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "Variant"
            },
            {
              "description": "Value to put into the Map",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "Long",
          "type": "Function"
        },
        {
          "description": "Puts all entries from a Map into this map",
          "name": "putAll",
          "parameters": [
            {
              "description": "Map to copy into this Map",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Map"
            }
          ],
          "returnType": "Map",
          "type": "Function"
        },
        {
          "description": "Puts a Pair into the Map, using key as the key and value as the Value.",
          "name": "putPair",
          "parameters": [
            {
              "description": "Pair to insert",
              "isbyval": "False",
              "islist": "False",
              "name": "content",
              "type": "Pair"
            }
          ],
          "returnType": "Long",
          "type": "Function"
        },
        {
          "description": "Removes an element from the Map based on its key.",
          "name": "removeByKey",
          "parameters": [
            {
              "description": "Key of element to remove",
              "isbyval": "False",
              "islist": "False",
              "name": "keyVal",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Removes a value or values from the Map",
          "name": "removeByValue",
          "parameters": [
            {
              "description": "Value to remove",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            },
            {
              "description": "Whether to remove all matches or just the first match",
              "isbyval": "False",
              "islist": "False",
              "name": "allMatches",
              "type": "Boolean"
            },
            {
              "description": "Comparator to use to check value",
              "isbyval": "False",
              "islist": "False",
              "name": "valueComparator",
              "type": "Comparator"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Reverses the keySet colection of a Map.",
          "name": "reverse",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Converts the Map to a JsonObject. If the values are objects, the code will try to call a toJson method on the object, otherwise skip them.",
          "name": "toJson",
          "parameters": [],
          "returnType": "JsonObject",
          "type": "Function"
        },
        {
          "description": "Transforms members of this Map usig a MapTransformer and adds them to the new Map passed.",
          "name": "transform",
          "parameters": [
            {
              "description": "MapTrasformer to transform members",
              "isbyval": "False",
              "islist": "False",
              "name": "transformer",
              "type": "MapTransformer"
            },
            {
              "description": "Map to load transformed members into",
              "isbyval": "False",
              "islist": "False",
              "name": "newMap",
              "type": "Map"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Unlocks the Map, so put, remove, replace and reverse functions can be used again",
          "name": "unlock",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "Comparator to compare keys with.",
          "name": "comparator",
          "parameters": [],
          "type": "Comparator"
        },
        {
          "default": "",
          "description": "Content-Type of values within the map",
          "name": "contentType",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Number of elements in the map",
          "name": "elementCount",
          "parameters": [],
          "type": "Long"
        },
        {
          "default": "",
          "description": "Flag indicating if the Map has elements",
          "name": "hasContent",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flag indicating if the Map is locked",
          "name": "isLocked",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flag indicating if the Map's keys are sorted",
          "name": "isSorted",
          "parameters": [],
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Suppress errors on adding or inserting elements. Errors wll still be thrown if the Map is locked",
          "name": "suppressErrors",
          "parameters": [],
          "type": "Boolean"
        }
      ],
      "class_variables": [],
      "description": "Map class",
      "name": "Map",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "Function to filter a Map's keys or values",
          "name": "filter",
          "parameters": [
            {
              "description": "Pair containg the key and value for the current element in the Map",
              "isbyval": "False",
              "islist": "False",
              "name": "kvPair",
              "type": "Pair"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class for filtering elements when filtering a Map",
      "name": "MapFilter",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Function to transform a member of a value. If there is no return value, the element is skipped and nothing gets added to the new Map for this element.",
          "name": "transform",
          "parameters": [
            {
              "description": "Pair containing key and value for the current element in the Map",
              "isbyval": "False",
              "islist": "False",
              "name": "kvPair",
              "type": "Pair"
            }
          ],
          "returnType": "Pair",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class for transforming elements in a Map to something else",
      "name": "MapTransformer",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "Overrides compare method in base class. Compare function, assuming both source and target are the same data type.",
          "name": "compare",
          "parameters": [
            {
              "description": "Element being inserted",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Element at current position",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "Variant"
            }
          ],
          "returnType": "Integer",
          "type": "Function"
        },
        {
          "description": "Fnction to determine if twi values are determined to be identical.",
          "name": "equals",
          "parameters": [
            {
              "description": "Element being inserted",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "Element at current position",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [
            {
              "description": "Whether sorting should be in descending order",
              "isbyval": "False",
              "islist": "False",
              "name": "isDescending",
              "type": "Boolean"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Class for comparing, ignoring data type check",
      "name": "MatchingDataTypeComparator",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "",
          "name": "New",
          "parameters": [
            {
              "description": "Key for the pair. Required at initialization, cannot be changed afterwards.",
              "isbyval": "False",
              "islist": "False",
              "name": "key",
              "type": "Variant"
            },
            {
              "description": "Value for the pair. Required at initialization, cannot be changed afterwards.",
              "isbyval": "False",
              "islist": "False",
              "name": "value",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "Key for the pair",
          "name": "key",
          "parameters": [],
          "type": "Variant"
        },
        {
          "default": "",
          "description": "",
          "name": "value",
          "parameters": [],
          "type": "Variant"
        }
      ],
      "class_variables": [],
      "description": "Base class for ky/value pair",
      "name": "Pair",
      "namespace": "VoltScriptCollections"
    },
    {
      "class_methods": [
        {
          "description": "Overrides parent method, forcing to string if possible",
          "name": "add",
          "parameters": [
            {
              "description": "A stringable scalar value",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Long",
          "type": "Function"
        },
        {
          "description": "Wrapper for CStr(Collection.getNthElementRaw(index)).",
          "name": "getNthElement",
          "parameters": [
            {
              "description": "Index of the element to return",
              "isbyval": "False",
              "islist": "False",
              "name": "index",
              "type": "Long"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [
            {
              "description": "Comparator, defaulting (if Nothing) to MatchingDataTypeComparator",
              "isbyval": "False",
              "islist": "False",
              "name": "comparator",
              "type": "Comparator"
            },
            {
              "description": "Flag indicating if the elements within the Collection must be unique",
              "isbyval": "False",
              "islist": "False",
              "name": "mustBeUnique",
              "type": "Boolean"
            },
            {
              "description": "Flag indicating if the content within the Collection should be sorted",
              "isbyval": "False",
              "islist": "False",
              "name": "isSorted",
              "type": "Boolean"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Collection that can only contain strings or scalars, which will be converted to strings",
      "name": "StringCollection",
      "namespace": "VoltScriptCollections"
    }
  ],
  "description": "Implement with USE <libs dir>/\"VoltScriptCollections\"",
  "methods": [],
  "name": "VoltScriptCollections",
  "properties": [],
  "types": [],
  "variables": []
}
