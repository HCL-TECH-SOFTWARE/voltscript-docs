{
  "classes": [
    {
      "class_methods": [
        {
          "description": "Function to call relevant \"New\" method of the class. Must be overridden.",
          "name": "createObject",
          "parameters": [
            {
              "description": "Class to create an instance of",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script file where the class is defined",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Creates a prefix for debug messages",
          "name": "getMeTypeForDebug",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Abstract class for calling any constructor that takes arguments when creating an object.",
      "name": "AbstractJsonConstructor",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Resets globals",
          "name": "cleanup",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Deserializes a JSON object into a property in a holder object",
          "name": "deserialize",
          "parameters": [
            {
              "description": "Object to deseralize into",
              "isbyval": "False",
              "islist": "False",
              "name": "holder",
              "type": "JsonConversionHolder"
            },
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Defines a custom property name from the relevant Class to use.",
          "name": "forPropertyName",
          "parameters": [
            {
              "description": "Property name to look for in the relevant Class. E.g. if the JSON has a label \"lastName\" but your class uses the property \"surname\", pass \"surname\" as the property to write to",
              "isbyval": "False",
              "islist": "False",
              "name": "propertyName",
              "type": "String"
            }
          ],
          "returnType": "AbstractJsonConverter",
          "type": "Function"
        },
        {
          "description": "Passes the current helper into the converter, so we know whether or not to suppress errors. <b>NOTE:</b> This method is called from the JsonConversionHelper, you should not call it in your own custom code.",
          "name": "fromHelper",
          "parameters": [
            {
              "description": "Helper from which the converter is being used",
              "isbyval": "False",
              "islist": "False",
              "name": "helper",
              "type": "JsonConversionHelper"
            }
          ],
          "returnType": "AbstractJsonConverter",
          "type": "Function"
        },
        {
          "description": "Main function to convert JSON value to VltScript value. Needs to be overridden in derived class.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Creates a prefix for debug messages",
          "name": "getMeTypeForDebug",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Whether or not the converter returns a VoltScript object or VoltScript scalar or scalar array.",
          "name": "isReturnObj",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Serializes a VoltScript value into a JSON object.",
          "name": "serialize",
          "parameters": [
            {
              "description": "VoltScript object from which to serialize",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "JsonObject to write value to",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Main function to convert VoltScript value to JSON value. Needs to be overridden in derived class.",
          "name": "toJson",
          "parameters": [
            {
              "description": "Variant containing the propery to be serialized",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [
        {
          "attribute": "",
          "default": "",
          "description": "",
          "name": "labelName",
          "type": "String"
        },
        {
          "attribute": "",
          "default": "",
          "description": "",
          "name": "prefix",
          "type": "String"
        }
      ],
      "description": "Base Converter to convert JSON to VoltScript datatype or object and vice versa.",
      "name": "AbstractJsonConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Destructor, erases converters List",
          "name": "Delete",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function",
          "name": "deserialize",
          "parameters": [
            {
              "description": "Object to deserialize to",
              "isbyval": "False",
              "islist": "False",
              "name": "holder",
              "type": "JsonConversionHolder"
            },
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function",
          "name": "serialize",
          "parameters": [
            {
              "description": "VoltScript object from which to serialize",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "JsonObject to write to",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Passes a custom converter to this AbstractJsonFunctionConverter. The converter will be used to convert the relevant label to a VoltScript object rather than a scalar or scalar array.",
          "name": "withCustomConverter",
          "parameters": [
            {
              "description": "Label to look for in the parent JSON object",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            },
            {
              "description": "AbstractJsonConverter to use when deserializing the value",
              "isbyval": "False",
              "islist": "False",
              "name": "converter",
              "type": "AbstractJsonConverter"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Fluent method to pass a literal value as a parameter for the converter",
          "name": "withLiteralParam",
          "parameters": [
            {
              "description": "Literal value to pass to the relevant setter as nth parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "paramVal",
              "type": "Variant"
            }
          ],
          "returnType": "AbstractJsonFunctionConverter",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [
        {
          "attribute": "Array",
          "default": "",
          "description": "",
          "name": "params",
          "type": "ConverterParam"
        }
      ],
      "description": "Custom Converter to convert between a JSON value or values and VoltScript datatype or objects, using a specific sub or function in the underlying class. Used as the abstract class for JsonGetterConverter and JsonSetterConverter.",
      "name": "AbstractJsonFunctionConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "description": "\"ScalarValue\" (only relevant to setters), \"JSON\" (only relevant to constructors), \"Parent\" (only relevant to setters, used to get siblings), \"Literal\"",
              "isbyval": "False",
              "islist": "False",
              "name": "paramType",
              "type": "String"
            },
            {
              "description": "Label in the relevant JSON object from which to extract a value",
              "isbyval": "False",
              "islist": "False",
              "name": "label",
              "type": "String"
            },
            {
              "description": "Default to use if label is not found",
              "isbyval": "False",
              "islist": "False",
              "name": "defaultValue",
              "type": "Variant"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "Label in the relevant JSON object from which to extract the value.",
          "name": "label",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Parameter type, \"ScalarValue\", \"JSON\", \"Parent\", or \"Literal\"",
          "name": "paramType",
          "parameters": [],
          "type": "String"
        }
      ],
      "class_variables": [
        {
          "attribute": "",
          "default": "",
          "description": "",
          "name": "value",
          "type": "Variant"
        }
      ],
      "description": "Class to hold details from which to extract a parameter for a setter or constructor.",
      "name": "ConverterParam",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overridden function. The fromJson method is called from AbstractJsonConverter's deserialize method.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function. The toJson method is called from AbstractJsonConverter's serialize method.",
          "name": "toJson",
          "parameters": [
            {
              "description": "Scalar or array variant containing serialized value",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Passes a custom converter to this JsonArrayConverter. The converter will be used to convert each element in the array to a VoltScript object rather than a scalar or scalar array.",
          "name": "withCustomConverter",
          "parameters": [
            {
              "description": "Converter to use when deserializing",
              "isbyval": "False",
              "islist": "False",
              "name": "converter",
              "type": "AbstractJsonConverter"
            }
          ],
          "returnType": "JsonArrayConverter",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Custom converter to convert a JSON value to VoltScript array",
      "name": "JsonArrayConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overrides base function",
          "name": "fromHelper",
          "parameters": [
            {
              "description": "Helper from which the converter is being used",
              "isbyval": "False",
              "islist": "False",
              "name": "helper",
              "type": "JsonConversionHelper"
            }
          ],
          "returnType": "AbstractJsonConverter",
          "type": "Function"
        },
        {
          "description": "Overridden function. The fromJson method is called from AbstractJsonConverter's deserialize method.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script file where the class is defined",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function. The toJson method is called from AbstractJsonConverter's serialize method.",
          "name": "toJson",
          "parameters": [
            {
              "description": "Variant containing the property to be serialized",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Passes a JsonConversionHelper with which to convert the object",
          "name": "withHelper",
          "parameters": [
            {
              "description": "JsonConversionHelper with settings to use during conversion",
              "isbyval": "False",
              "islist": "False",
              "name": "helper",
              "type": "JsonConversionHelper"
            }
          ],
          "returnType": "JsonBasicObjectArrayConverter",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Custom converter to convert a JSON value to an array of VoltScript objects, potentially using passed JsonConversionHelper.",
      "name": "JsonBasicObjectArrayConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overrides base method",
          "name": "fromHelper",
          "parameters": [
            {
              "description": "Helper from which the converter is being used",
              "isbyval": "False",
              "islist": "False",
              "name": "helper",
              "type": "JsonConversionHelper"
            }
          ],
          "returnType": "AbstractJsonConverter",
          "type": "Function"
        },
        {
          "description": "Overridden function. The fromJson method is called from AbstractJsonConverter's deserialize method.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "description": "Class to create an instance of",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script file where the class is defined",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function. The toJson method is called from AbstractJsonConverter's serialize method.",
          "name": "toJson",
          "parameters": [
            {
              "description": "Variant containing the property to be serialized",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Passes a JsonConversionHelper with which to convert the object",
          "name": "withHelper",
          "parameters": [
            {
              "description": "JsonConversionHelper with settings to use during conversion",
              "isbyval": "False",
              "islist": "False",
              "name": "helper",
              "type": "JsonConversionHelper"
            }
          ],
          "returnType": "JsonBasicObjectConverter",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Custom converter to convert a JSON value to a VoltScript object, potentially using a passed JsonConversionHelper",
      "name": "JsonBasicObjectConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Destructor, outputs (if in debug) which functions have been logged as encountered and erases converters List.",
          "name": "Delete",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Disables debug printing, switched off by default.",
          "name": "disableDebug",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Enables debug printing, switched off by default.",
          "name": "enableDebug",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Main function to deserialize a JSON object to a VoltScript object.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JSON object to deserialize",
              "isbyval": "False",
              "islist": "False",
              "name": "obj",
              "type": "JsonObject"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Parses JSON string and calls fromJson which creates an array or object.",
          "name": "fromJsonString",
          "parameters": [
            {
              "description": "String of JSON to parse",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "String"
            },
            {
              "description": "Class name to create object for",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script containing className",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Returns the custom converter for a label, if it exists.",
          "name": "getCustomConverter",
          "parameters": [
            {
              "description": "Label to match against",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            }
          ],
          "returnType": "AbstractJsonConverter",
          "type": "Function"
        },
        {
          "description": "Specifies a label to skip when parsing the JSON. The check is case-sensitive, so casing needs to match the casing in the JSON object.",
          "name": "ignoreLabel",
          "parameters": [
            {
              "description": "Label in JSON being parsed",
              "isbyval": "False",
              "islist": "False",
              "name": "labelToIgnore",
              "type": "String"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Converts an array to objects create with a constructor that takes no parameters.",
          "name": "jsonArrayToObjects",
          "parameters": [
            {
              "description": "Array of JSON objects",
              "isbyval": "False",
              "islist": "False",
              "name": "array",
              "type": "JsonObject"
            },
            {
              "description": "Class name to create object for",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script containing className",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Resets the holder object containing the return value. This allows you to re-use the helper.",
          "name": "reset",
          "parameters": [],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Checks whether to skip a label when parsing the JSON",
          "name": "shouldIgnoreLabel",
          "parameters": [
            {
              "description": "Label in JSON being parsed",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Main functon to serialize a VoltScript object / array to a JSON object",
          "name": "toJson",
          "parameters": [
            {
              "description": "VoltScript object or array of VoltScript objects to serialize",
              "isbyval": "False",
              "islist": "False",
              "name": "obj",
              "type": "Variant"
            }
          ],
          "returnType": "JsonObject",
          "type": "Function"
        },
        {
          "description": "Main function to serialize a VoltScript object / array to a string",
          "name": "toJsonString",
          "parameters": [
            {
              "description": "VoltScript object or array of VoltScript objects to serialize",
              "isbyval": "False",
              "islist": "False",
              "name": "obj",
              "type": "Variant"
            },
            {
              "description": "Output prettified JSON string or compressed",
              "isbyval": "False",
              "islist": "False",
              "name": "prettify",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Passes a JSON object to the helper and tells it what object type to create, defined in which file.",
          "name": "toObject",
          "parameters": [
            {
              "description": "JSON object to deserialize",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            },
            {
              "description": "Class to create an instance of",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script where the class is defined",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Adds an array converter to this object",
          "name": "withArrayConverter",
          "parameters": [
            {
              "description": "Label to look for in the JSON object (for deserialization) or VoltScript object (for serialization)",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Passes a custom constructor to use to create the object during deserialization",
          "name": "withCustomConstructor",
          "parameters": [
            {
              "description": "Custom constructor to use for creating the object",
              "isbyval": "False",
              "islist": "False",
              "name": "constructor",
              "type": "JsonCustomConstructor"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Adds a custom converter to this object",
          "name": "withCustomConverter",
          "parameters": [
            {
              "description": "Label to look for in the JSON object (for deserialization) or VoltScript object (for serialization)",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            },
            {
              "description": "Custom converter to apply",
              "isbyval": "False",
              "islist": "False",
              "name": "converter",
              "type": "AbstractJsonConverter"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Passes an existing object into the helper, so you can merge content from an additional JSON object into it.",
          "name": "withObject",
          "parameters": [
            {
              "description": "Object to merge properties into",
              "isbyval": "False",
              "islist": "False",
              "name": "object",
              "type": "Variant"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        },
        {
          "description": "Adds a scalar converter to this object",
          "name": "withScalarConverter",
          "parameters": [
            {
              "description": "Label to look for in the JSON object (for deserialization) or VoltScript object (for serialization)",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            }
          ],
          "returnType": "JsonConversionHelper",
          "type": "Function"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "",
          "name": "suppressErrors",
          "parameters": [],
          "type": "Boolean"
        }
      ],
      "class_variables": [],
      "description": "Helper class for performing the serialization / deserialization",
      "name": "JsonConversionHelper",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [
        {
          "attribute": "",
          "default": "",
          "description": "",
          "name": "contents",
          "type": "Variant"
        },
        {
          "attribute": "",
          "default": "",
          "description": "",
          "name": "isObject",
          "type": "Boolean"
        }
      ],
      "description": "Holder object for temporary output of serialization / deserialization",
      "name": "JsonConversionHolder",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Resets globals",
          "name": "cleanup",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function",
          "name": "createObject",
          "parameters": [
            {
              "description": "Class to create an instance of",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script file where the class is defined",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Destructor, erases converter list",
          "name": "Delete",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Passes a JSON object from which to extract parameter values",
          "name": "withContext",
          "parameters": [
            {
              "description": "JsonObject from which to extract parameters for constructor",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            },
            {
              "description": "List of AbstractJsonConverters with which to convert the parameters",
              "isbyval": "False",
              "islist": "True",
              "name": "converters",
              "type": "AbstractJsonConverter"
            }
          ],
          "returnType": "JsonCustomConstructor",
          "type": "Function"
        },
        {
          "description": "Fluent method to pass a literal value as a parameter for the constructor",
          "name": "withLiteralParam",
          "parameters": [
            {
              "description": "Literal value to pass to the constructor as nth parameter",
              "isbyval": "False",
              "islist": "False",
              "name": "paramVal",
              "type": "Variant"
            }
          ],
          "returnType": "JsonCustomConstructor",
          "type": "Function"
        },
        {
          "description": "Fluent method to retrieve a parameter value for the constructor from the JSON object or a default value to use if the label is not in the JSON object.",
          "name": "withParam",
          "parameters": [
            {
              "description": "Label to find in the JSON object",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            },
            {
              "description": "Default to use, if the label is not in the JSON",
              "isbyval": "False",
              "islist": "False",
              "name": "defaultValue",
              "type": "Variant"
            }
          ],
          "returnType": "JsonCustomConstructor",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [
        {
          "attribute": "Array",
          "default": "",
          "description": "",
          "name": "params",
          "type": "ConverterParam"
        }
      ],
      "description": "Base implementation of AbstractJsonConstructor for constructors that take parameters.",
      "name": "JsonCustomConstructor",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overridden function, throws error for that class - getters are only for serialization.",
          "name": "deserialize",
          "parameters": [
            {
              "description": "Object to deserialize to",
              "isbyval": "False",
              "islist": "False",
              "name": "holder",
              "type": "JsonConversionHolder"
            },
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Passes the getter name to look for in the relevant class",
          "name": "forGetter",
          "parameters": [
            {
              "description": "Function in the target class",
              "isbyval": "False",
              "islist": "False",
              "name": "getterName",
              "type": "String"
            }
          ],
          "returnType": "JsonGetterConverter",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function",
          "name": "serialize",
          "parameters": [
            {
              "description": "VoltScript object from which to serialize",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "JsonObject to write to",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Custom getter converter",
      "name": "JsonGetterConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overridden function",
          "name": "createObject",
          "parameters": [
            {
              "description": "Class to create an instance of",
              "isbyval": "False",
              "islist": "False",
              "name": "className",
              "type": "String"
            },
            {
              "description": "Script file where the class is defined",
              "isbyval": "False",
              "islist": "False",
              "name": "libName",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Base implementation of AbstractJsonConstructor for empty constructors",
      "name": "JsonNoArgsConstructor",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overridden function, uses scalar value from JSON object. The fromJson method is called from AbstractJsonConverter's deserialize method.",
          "name": "fromJson",
          "parameters": [
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Overridden function, always returning False for this Class",
          "name": "isReturnObj",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function. The toJson method is called from AbstractJsonConverter's serialize method.",
          "name": "toJson",
          "parameters": [
            {
              "description": "Variant containing the property to be serialized",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Cusom Converter to convert a JSON value to VoltScript scalar. This is used as the default for any conversion.",
      "name": "JsonScalarConverter",
      "namespace": "VoltScriptJSONConverter"
    },
    {
      "class_methods": [
        {
          "description": "Overridden function.",
          "name": "deserialize",
          "parameters": [
            {
              "description": "Object to deserialize to",
              "isbyval": "False",
              "islist": "False",
              "name": "holder",
              "type": "JsonConversionHolder"
            },
            {
              "description": "JSON object to deserialize from",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Passes the setter name to look for in the relevant class",
          "name": "forSetter",
          "parameters": [
            {
              "description": "Sub or function in the target class",
              "isbyval": "False",
              "islist": "False",
              "name": "setterName",
              "type": "String"
            }
          ],
          "returnType": "JsonSetterConverter",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overridden function, throws error",
          "name": "serialize",
          "parameters": [
            {
              "description": "VoltScript object from which to serialize",
              "isbyval": "False",
              "islist": "False",
              "name": "source",
              "type": "Variant"
            },
            {
              "description": "JsonObject to write value to",
              "isbyval": "False",
              "islist": "False",
              "name": "target",
              "type": "JsonObject"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Fluent method to retrieve a parameter value fr the setter from the JSON object, or a default value to use if the label is not in the JSON object. The relevant value is passed as the nth parameter to pass to the relevant setter.",
          "name": "withSiblingParam",
          "parameters": [
            {
              "description": "Label to search for at the same level as the JSON object being parsed",
              "isbyval": "False",
              "islist": "False",
              "name": "labelName",
              "type": "String"
            },
            {
              "description": "Default to use if the label is not found in the JSON",
              "isbyval": "False",
              "islist": "False",
              "name": "defaultValue",
              "type": "Variant"
            }
          ],
          "returnType": "JsonSetterConverter",
          "type": "Function"
        },
        {
          "description": "Uses the scalar value of the JSON element the converter is associated with.",
          "name": "withValueParam",
          "parameters": [],
          "returnType": "JsonSetterConverter",
          "type": "Function"
        }
      ],
      "class_properties": [],
      "class_variables": [],
      "description": "Custom Converter to convert between a JSON value or values and VoltScript datatype or objects, using a specific sub or function in the underlying class. During deserialization, the relevant JSON objects will then be removed from the parent JSON object, to ensure they are not re-processed.",
      "name": "JsonSetterConverter",
      "namespace": "VoltScriptJSONConverter"
    }
  ],
  "description": "Implement with USE <libs dir>/\"VoltScriptJSONConverter\"",
  "methods": [
    {
      "description": "Prints a message to the console, if running with the debug flag. The debug flag is a private global variable, enabled by calling JsonConversionHelper.enableDebug(). Typically used to log key steps or data in the process flow.",
      "name": "DebugPrint_Samsara",
      "parameters": [
        {
          "description": "String to print",
          "isbyval": "False",
          "islist": "False",
          "name": "msg",
          "type": "String"
        }
      ],
      "returnType": "",
      "type": "Sub"
    },
    {
      "description": "Extracts a parameter to a specific index of SamsaraParamVals, using a ConverterParam and list of converters.",
      "name": "extractParam",
      "parameters": [
        {
          "description": "JsonObject from which to extract parameters for a function",
          "isbyval": "False",
          "islist": "False",
          "name": "source",
          "type": "JsonObject"
        },
        {
          "description": "index of parameters into which to extract the value",
          "isbyval": "False",
          "islist": "False",
          "name": "idex",
          "type": "Integer"
        },
        {
          "description": "ConverterParam object containing default value",
          "isbyval": "False",
          "islist": "False",
          "name": "currParam",
          "type": "ConverterParam"
        },
        {
          "description": "List of AbstractSamsaraConverters to use to convert the value",
          "isbyval": "False",
          "islist": "True",
          "name": "converters",
          "type": "AbstractJsonConverter"
        }
      ],
      "returnType": "",
      "type": "Sub"
    },
    {
      "description": "",
      "name": "loadLogWritersFromJson",
      "parameters": [
        {
          "description": "String of JSON or path to file",
          "isbyval": "False",
          "islist": "False",
          "name": "context",
          "type": "String"
        }
      ],
      "returnType": "Variant",
      "type": "Function"
    },
    {
      "description": "Logs a function as encountered, if running with the debug flag",
      "name": "samsaraTouchFunction",
      "parameters": [
        {
          "description": "Function being touched",
          "isbyval": "False",
          "islist": "False",
          "name": "functionName",
          "type": "String"
        }
      ],
      "returnType": "",
      "type": "Sub"
    }
  ],
  "name": "VoltScriptJSONConverter",
  "properties": [],
  "types": [],
  "variables": [
    {
      "attribute": "",
      "default": "",
      "description": "",
      "name": "samsaraFunctionsTouched",
      "type": "Variant"
    },
    {
      "attribute": "",
      "default": "",
      "description": "",
      "name": "samsaraObj",
      "type": "Variant"
    },
    {
      "attribute": "",
      "default": "",
      "description": "",
      "name": "samsaraParamVals",
      "type": "Variant"
    },
    {
      "attribute": "",
      "default": "",
      "description": "",
      "name": "samsaraVal",
      "type": "Variant"
    }
  ]
}
