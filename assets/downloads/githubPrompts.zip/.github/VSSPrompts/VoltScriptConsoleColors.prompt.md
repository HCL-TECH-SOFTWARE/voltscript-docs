{
  "classes": [],
  "description": "Implement with USE <libs dir>/\"VoltScriptConsoleColors\"",
  "methods": [],
  "name": "VoltScriptConsoleColors",
  "properties": [
    {
      "default": "",
      "description": "Adds bold to output (ESC[2m)",
      "name": "CONSOLE_ATTR_BOLD",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Removes bold from console text (ESC[22m)",
      "name": "CONSOLE_ATTR_NO_BOLD",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Removes underscore from output (ESC[24m)",
      "name": "CONSOLE_ATTR_NO_UNDERSCORE",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Adds underscore to output (ESC[4m)",
      "name": "CONSOLE_ATTR_UNDERSCORE",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to black (ESC[40m)",
      "name": "CONSOLE_BACKGROUND_COLOR_BLACK",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to blue (ESC[44m)",
      "name": "CONSOLE_BACKGROUND_COLOR_BLUE",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to cyan (ESC[46m)",
      "name": "CONSOLE_BACKGROUND_COLOR_CYAN",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets just the background color to default (ESC[49m)",
      "name": "CONSOLE_BACKGROUND_COLOR_DEFAULT",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to green (ESC[42m)",
      "name": "CONSOLE_BACKGROUND_COLOR_GREEN",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to magenta (ESC[45m)",
      "name": "CONSOLE_BACKGROUND_COLOR_MAGENTA",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to red (ESC[41m)",
      "name": "CONSOLE_BACKGROUND_COLOR_RED",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets the background color to white (ESC[47m)",
      "name": "CONSOLE_BACKGROUND_COLOR_WHITE",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets background color to yellow (ESC[43m)",
      "name": "CONSOLE_BACKGROUND_COLOR_YELLOW",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets forground color to black (ESC[30m)",
      "name": "CONSOLE_COLOR_BLACK",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foreground color to blue (ESC[34m)",
      "name": "CONSOLE_COLOR_BLUE",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foreground color to cyan (ESC[36m)",
      "name": "CONSOLE_COLOR_CYAN",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets just foreground color to default (ESC[39m)",
      "name": "CONSOLE_COLOR_DEFAULT",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foregorund color to green (ESC[32m)",
      "name": "CONSOLE_COLOR_GREEN",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foreground color to magenta (ESC[35m)",
      "name": "CONSOLE_COLOR_MAGENTA",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foreground color to red (ESC[31m)",
      "name": "CONSOLE_COLOR_RED",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foreground color to white (ESC[37m)",
      "name": "CONSOLE_COLOR_WHITE",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Sets foreground color to yellow (ESC[33m)",
      "name": "CONSOLE_COLOR_YELLOW",
      "parameters": [],
      "type": "String"
    },
    {
      "default": "",
      "description": "Resets all attributes and colors to defaults (ESC[0m)",
      "name": "CONSOLE_DEFAULT",
      "parameters": [],
      "type": "String"
    }
  ],
  "types": [],
  "variables": []
}
