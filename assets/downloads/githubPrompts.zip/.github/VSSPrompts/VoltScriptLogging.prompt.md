{
  "classes": [
    {
      "class_methods": [
        {
          "description": "Generates a message using information from a logEntry instance and the object's formatter text (one of the constructor arguments).  Override this method to skip using the formatter.",
          "name": "convertLogEntryToMessage",
          "parameters": [
            {
              "description": "Log Entry from which to generate the message.",
              "isbyval": "False",
              "islist": "False",
              "name": "logEntry",
              "type": "LogEntry"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Destructor for the class.  ",
          "name": "Delete",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overload this method to do any setup before processing the LogEntry objects.",
          "name": "initializeLog",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Constructor for the object.",
          "name": "New",
          "parameters": [
            {
              "description": "Name for the log writer, which will be the key when added to the session",
              "isbyval": "False",
              "islist": "False",
              "name": "label",
              "type": "String"
            },
            {
              "description": "Minimum level to log out",
              "isbyval": "False",
              "islist": "False",
              "name": "minLevel",
              "type": "Integer"
            },
            {
              "description": "Maximum level to log out",
              "isbyval": "False",
              "islist": "False",
              "name": "maxLevel",
              "type": "Integer"
            },
            {
              "description": "A string format to log out, which can include mustache template format to inlcude LogEntry properties",
              "isbyval": "False",
              "islist": "False",
              "name": "formatter",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Writes a message to the output.    Overload this message for specific implementations.",
          "name": "outputLogEntryMessage",
          "parameters": [
            {
              "description": "Message to be outputted",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Overload this method to do any setup after processing the LogEntry objects.  This method is called internally at the end of the writeToLog() method. ",
          "name": "terminateLog",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Write all entries, as appropriate, to the log. You should not need to modify this method, it is automatically called in the Delete methods.",
          "name": "writeToLog",
          "parameters": [
            {
              "description": "Session from which to get the entries to be written",
              "isbyval": "False",
              "islist": "False",
              "name": "session",
              "type": "LogSession"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "String to manage output format, using mustache templating for properties of a Log Entry. Mustache template variables must be upper case.",
          "name": "formatter",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Label with which to refer to the log writer",
          "name": "label",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Level at which to log out",
          "name": "maxLevel",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "",
          "name": "minLevel",
          "parameters": [],
          "type": "Integer"
        }
      ],
      "class_variables": [],
      "description": "Abstract class for writing log entries from the LogSession",
      "name": "BaseLogWriter",
      "namespace": "VoltScriptLogging"
    },
    {
      "class_methods": [
        {
          "description": "Summary information about the Error to be included when creating a LogEvent. ",
          "name": "getLogMessage",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Constructor. This will not add the error to the ErrorSession. It is called from ErrorSession.createErrorEntry() and ErrorSession.createCustomErrorEntry()",
          "name": "New",
          "parameters": [
            {
              "description": "Error message describing the error. If code is less than 1 the value of Error$() will be used.",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            },
            {
              "description": "Numeric code of the error. If less than 1 the value of Err() will be used.",
              "isbyval": "False",
              "islist": "False",
              "name": "code",
              "type": "Integer"
            },
            {
              "description": "Line number in the source code where the error occurred. If code is less than 1 the value of Erl() will be used.",
              "isbyval": "False",
              "islist": "False",
              "name": "lineNum",
              "type": "Integer"
            },
            {
              "description": "the Logging Level for conditionally creating a LogEntry",
              "isbyval": "False",
              "islist": "False",
              "name": "levelNum",
              "type": "Integer"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Outputs a summary of the object's property information to console. Only relevant for basic debugging.",
          "name": "printSummary",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "VoltScript class from which the the object creation was triggered (passed into the constructor). ",
          "name": "className",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Error code of the error.",
          "name": "code",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "Name of the VSS library where the object creation was triggered. ",
          "name": "libraryName",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Line number of the running code where the Error was triggered.",
          "name": "lineNum",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "The text message of the object (passed as an argument to the object's constructor).",
          "name": "message",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Name of the method (Property, Event, Sub, or Function) where the object creation was triggered. ",
          "name": "methodName",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Stack Trace of the object creation, delimited by LF, in the format of \"libraryName, methodName, linenum\" for each line in the stack trace.",
          "name": "stackTrace",
          "parameters": [],
          "type": "String"
        }
      ],
      "class_variables": [],
      "description": "Carrier for Error information.",
      "name": "ErrorEntry",
      "namespace": "VoltScriptLogging"
    },
    {
      "class_methods": [
        {
          "description": "Spawns a new Custom ErrorEntry object and adds it to the ErrorSession. This can be used instead of a Try/Catch. Conditionally spawns a LogEntry in the Global LogSession instance. ",
          "name": "createCustomErrorEntry",
          "parameters": [
            {
              "description": "Error message describing the error.  If code is less than 1 the value of Error$() will be used.",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            },
            {
              "description": "Numeric code of the error.  If less than 1 the value of Err() will be used.  ",
              "isbyval": "False",
              "islist": "False",
              "name": "code",
              "type": "Integer"
            },
            {
              "description": "Line number in the source code where the error occurred. If code is less than 1 the value of Erl() will be used. ",
              "isbyval": "False",
              "islist": "False",
              "name": "lineNum",
              "type": "Integer"
            },
            {
              "description": "Logging Level (NO_LOGGING, LOG_TRACE, LOG_DEBUG, etc).  Used for conditionally creating a LogEntry ",
              "isbyval": "False",
              "islist": "False",
              "name": "levelNum",
              "type": "Integer"
            }
          ],
          "returnType": "ErrorEntry",
          "type": "Function"
        },
        {
          "description": "Spawns a new ErrorEntry object and adds it to the ErrorSession.  Conditionally spawns a LogEntry in the Global LogSession instance. ",
          "name": "createErrorEntry",
          "parameters": [
            {
              "description": "Logging Level (NO_LOGGING, LOG_TRACE, LOG_DEBUG, etc).  Used for conditionally creating a LogEntry ",
              "isbyval": "False",
              "islist": "False",
              "name": "levelNum",
              "type": "Integer"
            }
          ],
          "returnType": "ErrorEntry",
          "type": "Function"
        },
        {
          "description": "Constructor for the object.  Can only be used when called from method getErrorSession() ",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Resets the ErrorSession and clears all error information. This method does not reset the globalLogSession.",
          "name": "reset",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "Count of errors currently contained in the ErrorSession. ",
          "name": "errorCount",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "Array of ErrorEntry objects representing all of the errors that have been added to the session. ",
          "name": "errors",
          "parameters": [],
          "type": "Variant"
        }
      ],
      "class_variables": [],
      "description": "Stack Collection of ErrorEntry objects. ",
      "name": "ErrorSession",
      "namespace": "VoltScriptLogging"
    },
    {
      "class_methods": [
        {
          "description": "Retrieves a property value for a specified property name",
          "name": "getPropertyValue",
          "parameters": [
            {
              "description": "Name of the property to be retrieved",
              "isbyval": "False",
              "islist": "False",
              "name": "propertyName",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor. This will not add the LogEntry to the globalLogSession. It is called from globalLogSession.createLogEntry()",
          "name": "New",
          "parameters": [
            {
              "description": "Logging Level for the LogEntry, restricted to the LOG_xxx constants",
              "isbyval": "False",
              "islist": "False",
              "name": "levelNum",
              "type": "Integer"
            },
            {
              "description": "A short message to log",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            },
            {
              "description": "Extended information to log",
              "isbyval": "False",
              "islist": "False",
              "name": "extInfo",
              "type": "String"
            },
            {
              "description": "ErrorEntry instance spawning the LogEntry instance.  Nothing if not being spawned by an ErrorEntry ",
              "isbyval": "False",
              "islist": "False",
              "name": "eeInstance",
              "type": "ErrorEntry"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Outputs a summary of the properties of the LogEntry to console. Only relevant for basic debugging.",
          "name": "printSummary",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "VoltScript class from which the the object creation was triggered (passed into the constructor). ",
          "name": "className",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "A unique identifier for the object",
          "name": "entryID",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Extended info that may be included with the message, such as debug info, stack trace, etc.  Set in the object's constructor. ",
          "name": "extInfo",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "The logging level assigned to the object.  Specified as an argument in the object's constructor. ",
          "name": "level",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "Name of the logging level for the object.",
          "name": "levelName",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Name of the VSS library where the object creation was triggered. ",
          "name": "libraryName",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Line number of the running code where VoltScriptLogging was called.",
          "name": "lineNum",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "The text message of the object (passed as an argument to the object's constructor).",
          "name": "message",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Name of the method (Property, Event, Sub, or Function) where the object creation was triggered. ",
          "name": "methodName",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Stack Trace of the object creation, delimited by LF, in the format of \"libraryName, methodName, linenum\" for each line in the stack trace.",
          "name": "stackTrace",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Timestamp of when the object instance was created. This is date/time in yyyy-MM-dd hh:mm:ss format in the current platform's timezone.",
          "name": "timeStamp",
          "parameters": [],
          "type": "String"
        },
        {
          "default": "",
          "description": "Unique identifier for the instance",
          "name": "uuID",
          "parameters": [],
          "type": "String"
        }
      ],
      "class_variables": [],
      "description": "Represents a single Log Entry in the LogSession",
      "name": "LogEntry",
      "namespace": "VoltScriptLogging"
    },
    {
      "class_methods": [
        {
          "description": "Adds a log writer to the object. ",
          "name": "addLogWriter",
          "parameters": [
            {
              "description": "Instance of BaseLogWriter or derived class",
              "isbyval": "False",
              "islist": "False",
              "name": "logWriter",
              "type": "BaseLogWriter"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Creates a new LogEntry object. ",
          "name": "createLogEntry",
          "parameters": [
            {
              "description": "the Logging Level of the entry; you can use the constant as well",
              "isbyval": "False",
              "islist": "False",
              "name": "levelNum",
              "type": "Integer"
            },
            {
              "description": "the text message of the entry",
              "isbyval": "False",
              "islist": "False",
              "name": "message",
              "type": "String"
            },
            {
              "description": "Any extended information to include with the entry or blank",
              "isbyval": "False",
              "islist": "False",
              "name": "extInfo",
              "type": "String"
            },
            {
              "description": "ErrorEntry instance spawning the LogEntry instance.  Nothing if not being spawned by an ErrorEntry ",
              "isbyval": "False",
              "islist": "False",
              "name": "eeInstance",
              "type": "ErrorEntry"
            }
          ],
          "returnType": "LogEntry",
          "type": "Function"
        },
        {
          "description": "Destructor, during which LogWriters are processed",
          "name": "Delete",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Filters the LogEntry objects into an array containing just those at or above the minimum level and also at or below the maximum level.",
          "name": "getLogEntriesByLevel",
          "parameters": [
            {
              "description": "Minimum level of logs to retrieve",
              "isbyval": "False",
              "islist": "False",
              "name": "minLevel",
              "type": "Integer"
            },
            {
              "description": "Maximum level of the logs to retrieve",
              "isbyval": "False",
              "islist": "False",
              "name": "maxLevel",
              "type": "Integer"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Retrieves the LogEntry with a specified ID.  Nothing if not found. ",
          "name": "getLogEntryByID",
          "parameters": [
            {
              "description": "the entryID of the desired log entry",
              "isbyval": "False",
              "islist": "False",
              "name": "entryID",
              "type": "String"
            }
          ],
          "returnType": "LogEntry",
          "type": "Function"
        },
        {
          "description": "Constructor. Can only be used from getLogSession(). Do not use this constructor, use getLogSession() instead.",
          "name": "New",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Removes a LogWriter instance from the LogSession's LogWriters.   ",
          "name": "removeLogWriter",
          "parameters": [
            {
              "description": "Instance of BaseLogWriter (or derived class) to be removed from the LogSession",
              "isbyval": "False",
              "islist": "False",
              "name": "logWriter",
              "type": "BaseLogWriter"
            }
          ],
          "returnType": "",
          "type": "Sub"
        },
        {
          "description": "Resets the LogSession.  Deletes all internal LogEntry instances, erases all internal LogWriter instances, and generates a new session id. ",
          "name": "reset",
          "parameters": [],
          "returnType": "",
          "type": "Sub"
        }
      ],
      "class_properties": [
        {
          "default": "",
          "description": "Number of LogEntry instances contained by the LogSession",
          "name": "entryCount",
          "parameters": [],
          "type": "Integer"
        },
        {
          "default": "",
          "description": "Array of entryIDs for all LogEntry instances contained within the object.   Returns and empty variant if no LogEntry instances exist.",
          "name": "entryIDs",
          "parameters": [],
          "type": "Variant"
        },
        {
          "default": "",
          "description": "The last LogEntry that has been added to the object.  Nothing if no LogEntry instances have been added.",
          "name": "lastEntry",
          "parameters": [],
          "type": "LogEntry"
        },
        {
          "default": "",
          "description": "unique ID/key for this logging session",
          "name": "sessionID",
          "parameters": [],
          "type": "String"
        }
      ],
      "class_variables": [
        {
          "attribute": "List",
          "default": "",
          "description": "BaseLogWriters or classes extending BaseLogWriter.  ListTag is writer label.",
          "name": "logWriters",
          "type": "BaseLogWriter"
        }
      ],
      "description": "Base class for VoltScript logging",
      "name": "LogSession",
      "namespace": "VoltScriptLogging"
    }
  ],
  "description": "Implement with USE <libs dir>/\"VoltScriptLogging\"",
  "methods": [
    {
      "description": "Gets the ErrorSession ",
      "name": "getErrorSession",
      "parameters": [],
      "returnType": "ErrorSession",
      "type": "Function"
    }
  ],
  "name": "VoltScriptLogging",
  "properties": [],
  "types": [],
  "variables": [
    {
      "attribute": "Const",
      "default": "2",
      "description": "Fifth-highest logging level, for more extensive messages than most support requires.",
      "name": "LOG_DEBUG",
      "type": "Integer"
    },
    {
      "attribute": "Const",
      "default": "5",
      "description": "Second-highest logging level, for errors that are not fatal to continuing process.",
      "name": "LOG_ERROR",
      "type": "Integer"
    },
    {
      "attribute": "Const",
      "default": "6",
      "description": "Highest logging level.",
      "name": "LOG_FATAL",
      "type": "Integer"
    },
    {
      "attribute": "Const",
      "default": "3",
      "description": "Fourth-highest logging level, for informational messages.",
      "name": "LOG_INFO",
      "type": "Integer"
    },
    {
      "attribute": "Const",
      "default": "1",
      "description": "Lowest logging level, for most verbose logging.",
      "name": "LOG_TRACE",
      "type": "Integer"
    },
    {
      "attribute": "Const",
      "default": "4",
      "description": "Third-highest logging level, for log entries that are not errors but should be addressed.",
      "name": "LOG_WARN",
      "type": "Integer"
    },
    {
      "attribute": "Const",
      "default": "0",
      "description": "Only used in LogWriters, to prevent logging any log entries.",
      "name": "NO_LOGGING",
      "type": "Integer"
    },
    {
      "attribute": "",
      "default": "",
      "description": "Global Logging Session",
      "name": "globalLogSession",
      "type": "LogSession"
    }
  ]
}
