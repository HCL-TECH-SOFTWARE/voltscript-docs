{
  "classes": [
    {
      "description": "",
      "methods": [
        {
          "description": "Builds a DateTimeObject offset from Jan 1 1970 midnght UTC.",
          "name": "BuildDateTimeFromEpoch",
          "parameters": [
            {
              "default": "",
              "description": "Number of seconds since Jan 1 1970 midnight UTC",
              "name": "EpochSeconds",
              "optional": "False",
              "type": "Long-Unsigned"
            }
          ],
          "returnType": "DateTimeObject",
          "type": "Function"
        },
        {
          "description": "Builds a DateTimeObject from constituent parts of the date.",
          "name": "BuildDateTimeObject",
          "parameters": [
            {
              "default": "",
              "description": "Year to use",
              "name": "Year",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Month of the year, 1 to 12",
              "name": "Month",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Day of the month 1 to 28/29/30/31",
              "name": "Day",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Hours of the day, 0 to 23",
              "name": "Hours",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Minute of the hour, 0 to 59",
              "name": "Minutes",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Seconds of the minute, 0 to 59",
              "name": "Seconds",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Offset from UTC in minutes, e.g. US Eastern Time will be -5 x 60 = -3000, making 00:00 Eastern = 05:00 UTC.",
              "name": "UTCOffsetMinutes",
              "optional": "False",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "DateTimeObject",
          "type": "Function"
        },
        {
          "description": "Converts Lotuscript custom datetime format into c++ datetime format",
          "name": "ConvertLSFormat",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Format",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets the current server time as a DateTimeObject.",
          "name": "GetNow",
          "parameters": [],
          "returnType": "DateTimeObject",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "DateTimeParser",
          "type": "Function"
        },
        {
          "description": "Creates a DateTimeObject with a date time string, passing the format and locale with which to parse the string.",
          "name": "ParseDateString",
          "parameters": [
            {
              "default": "",
              "description": "String of some date-time format",
              "name": "DateTime",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Format with which to parse the string",
              "name": "Format",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Locale to apply when parsing the date-time string",
              "name": "Locale",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "DateTimeObject",
          "type": "Function"
        },
        {
          "description": "Creates a DateTimeObject from an ISO 8601 date-time format, either ending with Z or an offset.",
          "name": "ParseISOstring",
          "parameters": [
            {
              "default": "",
              "description": "String in ISO 8601 date-time format",
              "name": "ISODateTime",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "DateTimeObject",
          "type": "Function"
        },
        {
          "description": "",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "DateTimeParser",
      "namespace": "ZuluVSE",
      "properties": [
        {
          "default": "LIT_STR(\"1.0\")",
          "description": "",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "",
      "methods": [
        {
          "description": "Checks whether a passed DateTimeObject is after this DateTimeObject.",
          "name": "IsAfter",
          "parameters": [
            {
              "default": "",
              "description": "DateTimeObject to compare to this",
              "name": "DateTime",
              "optional": "False",
              "type": "DateTimeObject"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks whether a passed DateTimeObject is before this DateTimeObject.",
          "name": "IsBefore",
          "parameters": [
            {
              "default": "",
              "description": "DateTimeObject to compare to this",
              "name": "DateTime",
              "optional": "False",
              "type": "DateTimeObject"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks whether a passed DateTimeObject is identical to this DateTimeObject.",
          "name": "IsEqual",
          "parameters": [
            {
              "default": "",
              "description": "DateTimeObject to compare to this",
              "name": "DateTime",
              "optional": "False",
              "type": "DateTimeObject"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "DateTimeObject",
          "type": "Function"
        },
        {
          "description": "Returns this DateTimeObject as a string in ISO 8601 date-time format.",
          "name": "ToISODateTime",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns this DateTimeObject as a string uses C/C++ formatting codes and locale.",
          "name": "ToString",
          "parameters": [
            {
              "default": "",
              "description": "Formatter comprising C/C++ format codes, see https://en.cppreference.com/w/c/chrono/strftime",
              "name": "Format",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Locale to return, e.g. fr_FR.UTF8. See https://saimana.com/list-of-country-locale-code/",
              "name": "Locale",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "DateTimeObject",
      "namespace": "ZuluVSE",
      "properties": [
        {
          "default": "0",
          "description": "Day of the month portion of DateTimeObject",
          "name": "Day",
          "type": "Integer-Unsigned"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "",
          "name": "DefaultFormat",
          "type": "String"
        },
        {
          "default": "0",
          "description": "Milliseconds from Jan 1 1970 midnight UTC",
          "name": "EpochTime",
          "type": "Long-Unsigned"
        },
        {
          "default": "0",
          "description": "epoch time in milliseconds",
          "name": "EpochTimeMS",
          "type": "Double"
        },
        {
          "default": "0",
          "description": "Hour of the day portion of DateTimeObject",
          "name": "Hours",
          "type": "Integer-Unsigned"
        },
        {
          "default": "0",
          "description": "Minute of the day portion of DateTimeObject",
          "name": "Minutes",
          "type": "Integer-Unsigned"
        },
        {
          "default": "0",
          "description": "Month of the year portion of DateTimeObject",
          "name": "Month",
          "type": "Integer-Unsigned"
        },
        {
          "default": "0",
          "description": "Seconds of the minute portion of DateTimeObject",
          "name": "Seconds",
          "type": "Integer-Unsigned"
        },
        {
          "default": "0",
          "description": "Year portion of DateTimeObject",
          "name": "Year",
          "type": "Integer-Unsigned"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*ZuluVSE\"",
  "name": "ZuluVSE"
}
