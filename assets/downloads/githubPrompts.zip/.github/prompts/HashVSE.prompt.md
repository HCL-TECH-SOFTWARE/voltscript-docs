{
  "classes": [
    {
      "description": "Utility class to create hashes, encode and decode Base64, and convert bytes to and from strings",
      "methods": [
        {
          "description": "Decodes a base64-encoded string, returning a string",
          "name": "Base64Decode",
          "parameters": [
            {
              "default": "",
              "description": "Base64 encoded string",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Decodes a base64-encoded string, returning a byte array",
          "name": "Base64DecodeB",
          "parameters": [
            {
              "default": "",
              "description": "Base64-encoded string",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Base64-encodes a string",
          "name": "Base64Encode",
          "parameters": [
            {
              "default": "",
              "description": "String to encode",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Base64-encodes a byte array as a string",
          "name": "Base64EncodeB",
          "parameters": [
            {
              "default": "",
              "description": "Array of bytes to encode",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Converts a byte array to a string, optionally hexifying the string",
          "name": "BytesToString",
          "parameters": [
            {
              "default": "",
              "description": "Array of bytes to convert",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "",
              "description": "Whether or not to hex the string",
              "name": "Hexify",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates an MD5 hash of a file at a given filepath",
          "name": "FileMD5",
          "parameters": [
            {
              "default": "",
              "description": "Path of file for which to create an MD5",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates a byte array of an MD5 hash for a file at a given location",
          "name": "FileMD5B",
          "parameters": [
            {
              "default": "",
              "description": "Path of file for which to create an MD5",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Creates an MD5 hash for a given string",
          "name": "MD5",
          "parameters": [
            {
              "default": "",
              "description": "String to hash",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates an MD5 hash as a byte array for a given byte array",
          "name": "MD5B",
          "parameters": [
            {
              "default": "",
              "description": "Array of bytes to hash",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "HashUtilities",
          "type": "Function"
        },
        {
          "description": "Creates a random array of bytes matching the number requested",
          "name": "RandomBytes",
          "parameters": [
            {
              "default": "",
              "description": "Number of bytes to return",
              "name": "ByteCount",
              "optional": "False",
              "type": "Integer-Signed"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Internal method used to register the VSE with the runtime registry.",
          "name": "RegisterLSXPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Creates a SHA-1 hash of a string",
          "name": "SHA1",
          "parameters": [
            {
              "default": "",
              "description": "String to hash",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates a SHA-1 hashed byte array of a passed byte array",
          "name": "SHA1B",
          "parameters": [
            {
              "default": "",
              "description": "Byte array to hash",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Creates a SHA-256 hash of a string",
          "name": "SHA256",
          "parameters": [
            {
              "default": "",
              "description": "String to hash",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates a SHA-256 hashed byte array of a passed byte array",
          "name": "SHA256B",
          "parameters": [
            {
              "default": "",
              "description": "Byte array to hash",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Creates a SHA-512 hash of a string",
          "name": "SHA512",
          "parameters": [
            {
              "default": "",
              "description": "String to hash",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates a SHA-512 hashed byte array of a passed byte array",
          "name": "SHA512B",
          "parameters": [
            {
              "default": "",
              "description": "Byte array to hash",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Converts a string to a byte array",
          "name": "StringToBytes",
          "parameters": [
            {
              "default": "",
              "description": "String to convert",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        }
      ],
      "name": "HashUtilities",
      "namespace": "HashVSE",
      "properties": [
        {
          "default": "",
          "description": "the version of openssl library used by this vse",
          "name": "OpenSSLVersion",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"1.0.2\")",
          "description": "",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "Utility class to create AES keys and encrypt / decrypt files",
      "methods": [
        {
          "description": "Convert byte array to string",
          "name": "BytesToText",
          "parameters": [
            {
              "default": "",
              "description": "Byte array",
              "name": "Bytes",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates a 128-bit AES key. ",
          "name": "CreateAES128Key",
          "parameters": [],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Creates a 256-bit AES key.",
          "name": "CreateAES256Key",
          "parameters": [],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Creates an AES initialization vector, required for encryption / decryption.",
          "name": "CreateAESIV",
          "parameters": [],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "",
          "name": "CreatePKCIKey",
          "parameters": [
            {
              "default": "",
              "description": "Output file for private key",
              "name": "PrivateKeyPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Output file for public key",
              "name": "PublicKeyPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Optional key file password",
              "name": "Password",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "4096",
              "description": "Optional size of key",
              "name": "BitLength",
              "optional": "True",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Takes a file at a source location and creates an AES decrypted version at a target location, using a passed AES initialization vector and key,  optionally overwriting any file at the target location. You will need to use the same initialization vector and key with which the file was encrypted.",
          "name": "FileDecryptAES",
          "parameters": [
            {
              "default": "",
              "description": "Source file location",
              "name": "InputFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Target file location",
              "name": "OutputFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "AES initialization vector as byte array",
              "name": "AESIV",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "",
              "description": "AES key as byte array",
              "name": "AESKey",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "LSXFalse",
              "description": "Whether or not to overwrite any existin file at the target location, default value is false",
              "name": "Overwrite",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Takes a file at a source location and creates an AES encrypted version at a target location, using a passed AES initialization vector and key,  optionally overwriting any file at the target location. Anyone trying to decrypt the file will need the same initialization vector and key with which the file was encrypted.",
          "name": "FileEncryptAES",
          "parameters": [
            {
              "default": "",
              "description": "Source file location",
              "name": "InputFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Target file location",
              "name": "OutputFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "AES initialization vector as byte array",
              "name": "AESIV",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "",
              "description": "AES key as byte array",
              "name": "AESKey",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "LSXFalse",
              "description": "Whether or not to overwrite any existin file at the target location, default value is false",
              "name": "Overwrite",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Contructor",
          "name": "New",
          "parameters": [],
          "returnType": "CryptoUtilities",
          "type": "Function"
        },
        {
          "description": "",
          "name": "PKCIDecryptBuffer",
          "parameters": [
            {
              "default": "",
              "description": "Byte array",
              "name": "Key",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "",
              "description": "",
              "name": "InputData",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "",
          "name": "PKCIDecryptFile",
          "parameters": [
            {
              "default": "",
              "description": "Must be private key",
              "name": "KeyFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "InputFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "OutputFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "",
              "name": "ForceWrite",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "",
              "name": "Password",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "PKCIEncryptBuffer",
          "parameters": [
            {
              "default": "",
              "description": "Byte array",
              "name": "Key",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "",
              "description": "",
              "name": "KeyIsPrivate",
              "optional": "False",
              "type": "Boolean"
            },
            {
              "default": "",
              "description": "Byte array",
              "name": "InputData",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "",
          "name": "PKCIEncryptFile",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "KeyFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "KeyIsPrivate",
              "optional": "False",
              "type": "Boolean"
            },
            {
              "default": "",
              "description": "",
              "name": "InputFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "OutputFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "",
              "name": "ForceWrite",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "",
              "name": "Password",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Convert an RSA private key  file on disk to a VoltScript byte array.  Optional password is used to decrypt a password protected key file.",
          "name": "PKCIReadPrivateKeyFile",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "KeyFilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "",
              "name": "Password",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Convert an RSA public key file on disk to a VoltScript byte array. Public key files are never encrypted, so this is a convenience method.",
          "name": "PKCIReadPublicKeyFile",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "KeyFilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Convert text string to byte array",
          "name": "TextToBytes",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "StringInput",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        }
      ],
      "name": "CryptoUtilities",
      "namespace": "HashVSE",
      "properties": []
    }
  ],
  "description": "Implement with UseVSE \"*HashVSE\"",
  "name": "HashVSE"
}
