{
  "classes": [
    {
      "description": "Object for holding XML objects.",
      "methods": [
        {
          "description": "Adds attribute into the current XMLObject using the provided label and value.",
          "name": "AddAttribute",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "Value",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Creates a new child in the current XMLObject using the provided label and value.",
          "name": "AddChild",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": ""
            },
            {
              "default": "",
              "description": "",
              "name": "Value",
              "optional": "False",
              "type": ""
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Adds a child to the current XMLObject using the provided XMLObject.",
          "name": "AddChildObject",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Object",
              "optional": "False",
              "type": "XMLObject"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Inserts a root tag/element and value. Raises an error if this XMLObject already has a primary tag.",
          "name": "AddRootTag",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "Value",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Finds an XMLObject within the current XMLObject using an array of labels to navigate down the hierarchy.",
          "name": "FindObjectByPath",
          "parameters": [
            {
              "default": "",
              "description": "Array of labels to use to find the XMLObject",
              "name": "Labels",
              "optional": "False",
              "type": ""
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Retrieves the attribute's value using the provided attribute label.",
          "name": "GetAttributeValue",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns the child XMLObject using the provided label. Raises an error if the specified child cannot be found.",
          "name": "GetChild",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Returns an array of all the child XMLObjects. Rasies an error if this object has no children.",
          "name": "GetChildren",
          "parameters": [],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Returns the value of the XML child with the provided label. Raises an error if the child does not exist or does not have a value.",
          "name": "GetChildValue",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns the parent XMLObject of this XMLObject. Returns itself if this does not have a parent. Raises an error if this XMLObject is empty.",
          "name": "GetParent",
          "parameters": [],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Checks the elements within the current XMLObject if it exists using an array of labels to navigate down the hierarchy.",
          "name": "IsDescendant",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks if the current XMLObject is empty.",
          "name": "IsEmpty",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Deletes the XML attribute using the provided attribute tag/label.",
          "name": "RemoveAttribute",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Removes the child XML object using the provided XML tag.",
          "name": "RemoveChild",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Tag",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Removes the the provided XMLObject from this XMLObject. Use the getChild() method first to get the exact child XMLObject you wish to remove.",
          "name": "RemoveChildObject",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Object",
              "optional": "False",
              "type": "XMLObject"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Replaces the first Child Object argument from the current XMLObject using the second Child Object argument.",
          "name": "ReplaceChildObject",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "FirstObject",
              "optional": "False",
              "type": "XMLObject"
            },
            {
              "default": "",
              "description": "",
              "name": "SecondObject",
              "optional": "False",
              "type": "XMLObject"
            }
          ],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Converts this XMLObject to a string, either pretty-printed or as raw format.",
          "name": "ToString",
          "parameters": [
            {
              "default": "",
              "description": "Whether or not to pretty-print the XML",
              "name": "PrettyPrint",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "XMLObject",
      "namespace": "XMLVSE",
      "properties": [
        {
          "default": "",
          "description": "A String array of all the attributes this XMLObject has.",
          "name": "Attributes",
          "type": "String"
        },
        {
          "default": "",
          "description": "Number of child elements this XMLObject has.",
          "name": "ChildCount",
          "type": "Integer-Unsigned"
        },
        {
          "default": "",
          "description": "Represents the root or primary tag of this XMLObject.",
          "name": "Tag",
          "type": "String"
        },
        {
          "default": "",
          "description": "Represents the value of this XMLObject, returns empty if this is a parent.",
          "name": "Value",
          "type": "String"
        }
      ]
    },
    {
      "description": "Class for parsing strings and files in XML.",
      "methods": [
        {
          "description": "Returns the parsed XML as a XMLObject.",
          "name": "GetRootXML",
          "parameters": [],
          "returnType": "XMLObject",
          "type": "Function"
        },
        {
          "description": "Reads the file from the provided filepath and parses it as XML.",
          "name": "LoadFromFile",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "XMLParser",
          "type": "Sub"
        },
        {
          "description": "Reads the provided string and parses it as a XML",
          "name": "LoadFromXML",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "XML",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "XMLParser",
          "type": "Sub"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "XMLParser",
          "type": "Function"
        },
        {
          "description": "Converts a parsed XML object to a string, pretty-printed with new lines or in a compact format.",
          "name": "ToString",
          "parameters": [
            {
              "default": "",
              "description": "Whether or not to pretty-print the XML ",
              "name": "PrettyPrint",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "XMLParser",
      "namespace": "XMLVSE",
      "properties": [
        {
          "default": "LIT_STR(\"1.0.2\")",
          "description": "",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*XMLVSE\"",
  "name": "XMLVSE"
}
