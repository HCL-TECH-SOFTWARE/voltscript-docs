{
  "classes": [
    {
      "description": "Class for connecting to and interacting with a CouchDB Server.  Provides methods for getting and setting configuration information. ",
      "methods": [
        {
          "description": "Creates a database using the specified name ",
          "name": "CreateDb",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchDatabase",
          "type": "Function"
        },
        {
          "description": "Deletes the specified database from the CouchDB Server ",
          "name": "DeleteDb",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Database",
              "optional": "False",
              "type": "CouchDatabase"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Gets the specified database (if it exists) ",
          "name": "GetDb",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchDatabase",
          "type": "Function"
        },
        {
          "description": "Gets a Universally Unique Identifier (UUID) from the CouchDb server instance ",
          "name": "GetUUID",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Boolean flag indicating if a database matching the specified DbName exists. ",
          "name": "IsDatabase",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "DbName",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Logs into the CouchDB Server using the previously set credentials and URL",
          "name": "Login",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Constructor method for a CouchServer object. ",
          "name": "New",
          "parameters": [],
          "returnType": "CouchServer",
          "type": "Function"
        },
        {
          "description": "INTERNAL METHOD used to register the VSE with the operating system.  Not needed by application developers.",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "CouchServer",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "Path to a .crt file containing certificates for the server to connect to, if not on the PATH.  This should only be necessary for self-signed certificates.   If the server requires SSL verification and there is no valid certificate or this is False then login will fail.",
          "name": "CertificatePath",
          "type": "String"
        },
        {
          "default": "",
          "description": "Version of CouchDB being used by the connected CouchServer",
          "name": "CouchVersion",
          "type": "String"
        },
        {
          "default": "",
          "description": "String array containing the names of all databases for a couch server.",
          "name": "DatabaseNames",
          "type": "String"
        },
        {
          "default": "",
          "description": "Array of Strings indicating the Features (such as \"access-ready\", \"partitioned\", etc) of the CouchDB Server",
          "name": "Features",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "The version of Libcurl used by this vse",
          "name": "LibCurlVersion",
          "type": "String"
        },
        {
          "default": "",
          "description": "Password used when logging into a CouchDB Server ",
          "name": "Password",
          "type": "String"
        },
        {
          "default": "True",
          "description": "Turn on or off SSL host validation. If the server requires SSL verification and there is no valid certificate or this is False then login will fail.   Settng SSLHostValidationOn to false can be used for internal HTTPS URLs on servers with self-signed certs. Default value is True.",
          "name": "SSLHostValidationOn",
          "type": "Boolean"
        },
        {
          "default": "LIT_STR(\"127.0.0.1:5984\")",
          "description": "URL Used to access the CouchDB Server",
          "name": "URL",
          "type": "String"
        },
        {
          "default": "",
          "description": "User name used when logging into a CouchDB Server",
          "name": "User",
          "type": "String"
        },
        {
          "default": "False",
          "description": "Whether this CouchServer should create a .log file with verbose logging output from libcurl when a request is made. This is helpful when debugging networking issues related to VPN's, proxies, self-signed SSL certificates, etc.",
          "name": "VerboseLogging",
          "type": "Boolean"
        },
        {
          "default": "LIT_STR(\"1.0.2\")",
          "description": "Represents the Version of the CouchVSE VoltScript extension in use. ",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "Represents a CouchDB Database    Creation - Use the CouchServer.CreateDb() method  Retrieval - Use the CouchServer.GetDb() method  Deletion - Use the CouchServer.DeleteDb() method",
      "methods": [
        {
          "description": "Creates a CouchAgent in the specified CouchDatabase",
          "name": "CreateAgent",
          "parameters": [
            {
              "default": "",
              "description": "Name of the CouchAgent to be created",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchAgent",
          "type": "Function"
        },
        {
          "description": "Creates a new CouchDocument",
          "name": "CreateDocument",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ID",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "JsonValues",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchDocument",
          "type": "Function"
        },
        {
          "description": "Creates a CouchView within the CouchDatabase",
          "name": "CreateView",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchView",
          "type": "Function"
        },
        {
          "description": "Deletes the secified CouchAgent from the CouchDatabase",
          "name": "DeleteAgent",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Deletes a document from the CouchDatabase",
          "name": "DeleteDocument",
          "parameters": [
            {
              "default": "",
              "description": "Docment to be deleted",
              "name": "Document",
              "optional": "False",
              "type": "CouchDocument"
            },
            {
              "default": "LSXFalse",
              "description": "Flag indicating if a deletion stub should be preserved ",
              "name": "Preserve",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Deletes the specified CouchDocument from the CouchDatabase",
          "name": "DeleteDocumentByID",
          "parameters": [
            {
              "default": "",
              "description": "ID of the CouchDocument to be deleted ",
              "name": "DocID",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "Flag indicating if the CouchDocument's data should be preserved even though the document is marked as _deleted.",
              "name": "Preserve",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "DeleteView",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Retrieves the specified CouchAgent from the CouchDatabase",
          "name": "GetAgent",
          "parameters": [
            {
              "default": "",
              "description": "Name of the CouchAgent to retrieve",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchAgent",
          "type": "Function"
        },
        {
          "description": "Gets the IDs of all deleted elements within the CouchDatabase ",
          "name": "GetDeletedIDs",
          "parameters": [
            {
              "default": "LSXFalse",
              "description": "",
              "name": "RememberLast",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets a specified CouchDocument from the CouchDatabase.  ",
          "name": "GetDocumentByID",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ID",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "",
              "name": "IncludeDeleted",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "CouchDocument",
          "type": "Function"
        },
        {
          "description": "Gets a specified CouchView from the CouchDatabase.  ",
          "name": "GetViewByID",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ViewID",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchView",
          "type": "Function"
        },
        {
          "description": "Indicates if a CouchAgent matching the specified name exists in the Couch Database",
          "name": "IsAgent",
          "parameters": [
            {
              "default": "",
              "description": "Name of the CouchAgent for which to check existence. ",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Indicates if a CouchAgent matching the specified name exists in the CouchDatabase",
          "name": "IsDocument",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "DocID",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Indicates if a CouchView matching the name exists in the CouchDatabase",
          "name": "IsView",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "NOT AVAILABLE - Use CouchServer.GetDatabase() or CouchServer.CreateDatabase() methods ",
          "name": "new",
          "parameters": [],
          "returnType": "CouchDatabase",
          "type": "Function"
        }
      ],
      "name": "CouchDatabase",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "NOT IMPLEMENTED",
          "name": "ACL",
          "type": "CouchACL"
        },
        {
          "default": "",
          "description": "String Array containig the Ids for all Documents within a Couch Database",
          "name": "DocumentIDs",
          "type": "String"
        },
        {
          "default": "",
          "description": "Name of a Couch Database ",
          "name": "Name",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"_local\")",
          "description": "Node within which the CouchDB Resides",
          "name": "Node",
          "type": "String"
        },
        {
          "default": "",
          "description": "",
          "name": "UpdateFunctions",
          "type": "String"
        },
        {
          "default": "",
          "description": "String Array containig the Ids for all Views within a Couch Database",
          "name": "ViewIDs",
          "type": "String"
        }
      ]
    },
    {
      "description": "NOT IMPLEMENTED",
      "methods": [
        {
          "description": "NOT IMPLEMENTED",
          "name": "New",
          "parameters": [],
          "returnType": "CouchACL",
          "type": "Function"
        }
      ],
      "name": "CouchACL",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "NOT IMPLEMENTED",
          "name": "Permissions",
          "type": "String"
        },
        {
          "default": "",
          "description": "NOT IMPLEMENTED",
          "name": "Roles",
          "type": "String"
        }
      ]
    },
    {
      "description": "Represents a Document in a CouchDatabase    Creation - Use the CouchDatabase.CreateDocument() method.  Retrieval - Use the CouchDatabase.GetDocumentByID() method  Deletion - Use the CouchDatabase.DeleteDocument() method ",
      "methods": [
        {
          "description": "Adds an Item to the CouchDocument    Returns a flag indicating success / failure of the operation. ",
          "name": "AddItem",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ItemName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "Value",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Adds an item to an existing JSON Object of a CouchDocument ",
          "name": "AddItemToJSONObject",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ItemName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "ObjectName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "Value",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Adds a JSON Object to a CouchDocument",
          "name": "AddJSONObject",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "JSONObject",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Creates a CouchAttachment object.  IMPORTANT NOTE: The newly created CouchAttachment object exists only in memory.  It must be uploaded using CouchAttachment.Upload() method in order to be saved to the Couch Database.",
          "name": "CreateAttachment",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "DiskFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "ContentType",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchAttachment",
          "type": "Function"
        },
        {
          "description": "Retrieves the named CouchAttachment object from the CouchDocument",
          "name": "GetAttachmentInfo",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Name",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchAttachment",
          "type": "Function"
        },
        {
          "description": "Gets the names of all CouchAttachments of a CouchDocument.",
          "name": "GetAttachmentNames",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "NOT IMPLEMENTED - To create a new CouchDocument you must use the CouchDatabase.CreateDocument() method ",
          "name": "new",
          "parameters": [],
          "returnType": "CouchDocument",
          "type": "Function"
        },
        {
          "description": "Saves a CouchDocument to the backing Apache Couch DB database.  Returns True if successful. ",
          "name": "Save",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "CouchDocument",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "NOT IMPLEMENTED - USE CouchDocument.getAttachmentNames() ",
          "name": "Attachments",
          "type": "String"
        },
        {
          "default": "",
          "description": "ID that uniquely identifes the CouchDocument within the CouchDatabase. ",
          "name": "ID",
          "type": "String"
        },
        {
          "default": "",
          "description": "Flag Indicating whether or not the in-memory CouchDocument has been modified since last saved.    Behavior Notes:   1) This will always return False for Newly created and not-yet-saved CouchDocument objects.  2)  If a CouchDocument has been saved (or newly retrieved from disk) and a CouchAttachment is added, this will return False.  3) If a CouchAttachment has been uploaded to a CouchDocument , this will return False.  4) If a new item is added to a CouchDocument, this will return True.",
          "name": "IsModified",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Flag indicating if an in-memory CouchDocument has been saved since last modified.      Behavior Notes:   1) This will always return False for Newly created and not-yet-saved CouchDocument objects.  2)  If a CouchDocument has been saved (or newly retrieved from disk) and a CouchAttachment is added, this will return True.  3) If a CouchAttachment has been uploaded to a CouchDocument , this will return True.  4) If a new item is added to a CouchDocument, this will return False.",
          "name": "IsSaved",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "JSON String containing information about the CouchDocument. ",
          "name": "JSONValue",
          "type": "String"
        },
        {
          "default": "",
          "description": "Unique code representing the revision value of the on-disk CouchDocument . This value is composed of 2 parts delimited by a hyphen.  This value is generated by Apache CouchDB itself, and if officially \"opaque\" - other than it is unique.     Behavior Notes: 1) This is not set until the CouchDocument has been saved.  2)  If a CouchDocument has been saved, and a CouchAttachment is added to it, this value does not change until the CouchAttachment has been Uploaded.  3) This value will change whenever a CouchAttachment is Uploaded",
          "name": "Revision",
          "type": "String"
        },
        {
          "default": "",
          "description": "URL of the CouchDocument   Follows the pattern  CouchServer.URL / CouchDatabase.Name / CouchDocuent.ID ",
          "name": "URL",
          "type": "String"
        }
      ]
    },
    {
      "description": "Represents a view within a CouchDatabase    Creation - Use the CouchDatabase.CreateView() method  Retrieval - Use the CouchDatabase.GetViewByID() method  Deletion - Use the CouchDatabase.DeleteView() method ",
      "methods": [
        {
          "description": "Allows iteration through a CouchView, returning a selected set of rows of information.     Returns String Array, with each element contining the JSON for the specific row it represents. ",
          "name": "GetRowArray",
          "parameters": [
            {
              "default": "",
              "description": "Number of rows to SKIP prior to retrieving requested rows. ",
              "name": "Skip",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Maximum number of rows to return. ",
              "name": "Limit",
              "optional": "False",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Retrieves a specific subset of rows from the CouchView.     Returns a JSON String containing the content of all rows in the result set.",
          "name": "GetRowsByKey",
          "parameters": [
            {
              "default": "",
              "description": "Key specifying the FIRST row to retrieve",
              "name": "StartKey",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Key specifying the LAST row to retrieve",
              "name": "EndKey",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "25",
              "description": "Maximum number of rows to retrieve",
              "name": "Limit",
              "optional": "True",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Allows iteration through a CouchView, returning a selected set of rows of information, includes meta information about the retrieved content (such as offset and number of rows in the view).      Returns a JSON String containing the content of all rows in the result set.",
          "name": "GetSomeRows",
          "parameters": [
            {
              "default": "",
              "description": "Number of rows to SKIP prior to retrieving requested rows. ",
              "name": "Skip",
              "optional": "False",
              "type": "Integer-Unsigned"
            },
            {
              "default": "",
              "description": "Maximum number of rows to return. ",
              "name": "Limit",
              "optional": "False",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets JSON information about the CouchView. ",
          "name": "GetViewInfo",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "NOT AVAILABLE - Use CouchDatabase.CreateView() or CouchDatabase.GetViewByID() methods",
          "name": "New",
          "parameters": [],
          "returnType": "CouchView",
          "type": "Function"
        },
        {
          "description": "NOT IMPLEMENTED",
          "name": "Query",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "query",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "CouchDocument",
          "type": "Function"
        },
        {
          "description": "Saves the CouchView object to the backing Apache CouchDB database.",
          "name": "Save",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "CouchView",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "NOT IMPLEMENTED",
          "name": "Filters",
          "type": "String"
        },
        {
          "default": "",
          "description": "ID that uniquely identifes the CouchView within the CouchDatabase. ",
          "name": "ID",
          "type": "String"
        },
        {
          "default": "",
          "description": "JSON String containing information about the CouchView. ",
          "name": "JSONValue",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"JavaScript\")",
          "description": "Programming Language for the CouchView -  JavaScript",
          "name": "Language",
          "type": "String"
        },
        {
          "default": "",
          "description": "Javascript code defining view selection and columns for the object.  Refer to Apache CouchDB Documentation",
          "name": "MapFunction",
          "type": "String"
        },
        {
          "default": "",
          "description": "Javascript code defining map reducing for the object.  Refer to Apache CouchDB Documentation",
          "name": "ReduceFunction",
          "type": "String"
        },
        {
          "default": "",
          "description": "Unique code representing the revision value of the on-disk CouchView . This value is composed of 2 parts delimited by a hyphen.  This value is generated by Apache CouchDB itself, and if officially \"opaque\" - other than it is unique.     Behavior Notes: 1) This is not set until the CouchView has been saved. ",
          "name": "Revision",
          "type": "String"
        }
      ]
    },
    {
      "description": "NOT IMPLEMENTED",
      "methods": [
        {
          "description": "NOT IMPLEMENTED",
          "name": "New",
          "parameters": [],
          "returnType": "CouchForm",
          "type": "Function"
        }
      ],
      "name": "CouchForm",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "NOT IMPLEMENTED",
          "name": "Name",
          "type": "String"
        },
        {
          "default": "",
          "description": "NOT IMPLEMENTED",
          "name": "Template",
          "type": "String"
        }
      ]
    },
    {
      "description": "Represents an agent within a CouchDatabase    Creation - Use the CouchDatabase.CreateAgent() method Retrieval - Use the CouchDatabase.GetAgent() method Deletion - Use the CouchDatabase.DeleteAgent() method",
      "methods": [
        {
          "description": "NOT IMPLEMENTED",
          "name": "ImportAgentJSON",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "FileName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "IsURL",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Imports source code into the CouchAgent",
          "name": "ImportAgentScript",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "FileName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "IsURL",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "NOT AVAILABLE  - Use CouchDatabase.CreateAgent() or CouchDatabase.GetAgent() methods",
          "name": "New",
          "parameters": [],
          "returnType": "CouchAgent",
          "type": "Function"
        },
        {
          "description": "Saves the CouchAgent to to the backing Apache Couch DB database. ",
          "name": "Save",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "CouchAgent",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "",
          "description": "Source code for the agent. ",
          "name": "AgentCode",
          "type": "String"
        },
        {
          "default": "",
          "description": "Programming language for which the CouchAgent has been written. ",
          "name": "AgentLanguage",
          "type": "String"
        },
        {
          "default": "",
          "description": "Meta information about the CouchAgent",
          "name": "AgentMetadata",
          "type": "String"
        },
        {
          "default": "",
          "description": "Name of the CouchAgent",
          "name": "Name",
          "type": "String"
        },
        {
          "default": "",
          "description": "Unique code representing the revision value of the on-disk CouchAgent . This value is composed of 2 parts delimited by a hyphen.  This value is generated by Apache CouchDB itself, and if officially \"opaque\" - other than it is unique.     Behavior Notes: 1) This is not set until the CouchAgent has been saved. ",
          "name": "Revision",
          "type": "String"
        }
      ]
    },
    {
      "description": "Carrier for Meta information about an attached file for a CouchDocument    Creation - Use the CouchDocument.CreateAttachment() method  Retrieval - Use the CouchDocument.GetAttachmentInfo() method. ",
      "methods": [
        {
          "description": "Downloads the file for the CouchAttachment object to the LOCAL filesystem. ",
          "name": "Download",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "DiskFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "Overwrite",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Long-Unsigned",
          "type": "Function"
        },
        {
          "description": "NOT AVAILABLE - Use CouchDocument.CreateAttachment() or CouchDocument.GetAttachmentInfo() methods. ",
          "name": "New",
          "parameters": [],
          "returnType": "CouchAttachment",
          "type": "Function"
        },
        {
          "description": "Uploads the LOCAL filesystem file to the ParentDatabase of the CouchAttachment.  ",
          "name": "Upload",
          "parameters": [],
          "returnType": "Long-Signed",
          "type": "Function"
        }
      ],
      "name": "CouchAttachment",
      "namespace": "CouchVSE",
      "properties": [
        {
          "default": "0",
          "description": "Number of Bytes used by the actual file referenced by the CouchAttachment object. ",
          "name": "ContentLength",
          "type": "Long-Unsigned"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "String describing the content type of the CouchAttachment.      NOTE: There is no logic or detection processes backing this property.  It is manually set and completely arbitrary. ",
          "name": "ContentType",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "The LOCAL filepath to the file for a CouchAttachment object.      NOTE: This is only valid for CouchAttachments which have been created during the current session. It will be blank for CouchAttachment objects retrieved from the CouchDatabas",
          "name": "DiskFile",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "NOT IMPLEMENTED",
          "name": "MD5Hash",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "Name of the CouchAttachment.     NOTE: There is no logic or detection processes backing this property.  It is manually set and completely arbitrary. ",
          "name": "Name",
          "type": "String"
        },
        {
          "default": "",
          "description": "CouchDocument object for which the CouchAttachment is associated. ",
          "name": "ParentDocument",
          "type": "CouchDocument"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*CouchVSE\"",
  "name": "CouchVSE"
}
