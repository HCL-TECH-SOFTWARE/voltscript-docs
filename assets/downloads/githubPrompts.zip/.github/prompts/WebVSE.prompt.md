{
  "classes": [
    {
      "description": "Class for building file and web URLs.",
      "methods": [
        {
          "description": "Adds a query string parameter to append to the TargetPath URL.",
          "name": "AddURLParameter",
          "parameters": [
            {
              "default": "",
              "description": "Key of the URL parameter, e.g. \"count\"",
              "name": "Key",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Value of the URL parameter, e.g. \"20\"",
              "name": "Value",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "URLBuilder",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "URLBuilder",
          "type": "Function"
        },
        {
          "description": "Removes a URL parameter. Note: parameters are an array of key/value pairs, so you cannot change a parameter. This would be done by removing the parameter and adding a new one.  One typical use case for this would be re-using the same URLBuilder for multiple calls with different query string arguments.",
          "name": "RemoveParameter",
          "parameters": [
            {
              "default": "",
              "description": "Key of URL parameter to be removed. If there is no parameter with the passed key, URL parameters are not changed and no error is raised.",
              "name": "Key",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "URLBuilder",
          "type": "Function"
        },
        {
          "description": "Outputs the URL as a string, using Protocol + TargetHost + TargetPath + URL parameters. Protocol is file:///, http:// or https://, depending on which property is set.  URL parameters are output in alphabetical order on key.",
          "name": "ToString",
          "parameters": [
            {
              "default": "LSXTrue",
              "description": "Whether or not to URL encode the string",
              "name": "URLEncode",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "URLBuilder",
      "namespace": "WebVSE",
      "properties": [
        {
          "default": "False",
          "description": "Sets this as a builder for file URIs, protocol will be file:///",
          "name": "IsFile",
          "type": "Boolean"
        },
        {
          "default": "True",
          "description": "Sets this as a builder for HTTP URIs, protocol will be http://",
          "name": "IsHTTP",
          "type": "Boolean"
        },
        {
          "default": "False",
          "description": "Sets this as a builder for HTTPS URIs, protocol will be https://",
          "name": "IsHTTPS",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Host URL to conncet to. This will be used as the HostURL property of the WebServer created.",
          "name": "TargetHost",
          "type": "String"
        },
        {
          "default": "",
          "description": "Endpoint path relative to the TargetHost. This will be used as the Target for the WbRequest created.",
          "name": "TargetPath",
          "type": "String"
        }
      ]
    },
    {
      "description": "Class for holding generic server information for web requests.",
      "methods": [
        {
          "description": "Creates a WebRequest for individual requests to this WebServer's HostURL",
          "name": "CreateRequest",
          "parameters": [],
          "returnType": "WebRequest",
          "type": "Function"
        },
        {
          "description": "Populates a WebRequest and WebServer with a full URL including protocol, host URL, target path and query string.",
          "name": "CreateRequestWithURL",
          "parameters": [
            {
              "default": "",
              "description": "URL to create WebRequest with",
              "name": "FullURL",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "WebRequest",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "WebServer",
          "type": "Function"
        },
        {
          "description": "Internal method used to register the VSE with the runtime registry.",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "URL decodes a string.",
          "name": "URLdecode",
          "parameters": [
            {
              "default": "",
              "description": "String to decode",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "URL encodes a string. This method does not encode alphanumerics or - _ . ~ / ? = & :",
          "name": "URLencode",
          "parameters": [
            {
              "default": "",
              "description": "String to URL encode",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "WebServer",
      "namespace": "WebVSE",
      "properties": [
        {
          "default": "",
          "description": "Path to a .crt file containing certificates for the server to connect to, if not on the PATH. Without a valid certificate or unless SSLHostValidationOn is set to False, the request will return a status 0, if the server requires SSL verification.",
          "name": "CertificatePath",
          "type": "String"
        },
        {
          "default": "",
          "description": "Base URL to use for all WebRequests created from this WebServer object. This gets set from a URLBuilder when calling WebServer.createRequestWithUrl().",
          "name": "HostURL",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "The version of Libcurl used by this VSE",
          "name": "LibCurlVersion",
          "type": "String"
        },
        {
          "default": "False",
          "description": "Whether or not cookies received from WebResponses should be preserved between WebRequests made from this WebServer. Default value is False.",
          "name": "PreserveCookies",
          "type": "Boolean"
        },
        {
          "default": "LIT_STR(\"HTTP\")",
          "description": "Protocol to use when making WebRequests. Default is \"HTTP\".",
          "name": "Protocol",
          "type": "String"
        },
        {
          "default": "True",
          "description": "Turn on or off SSL host validation. Without a valid certificate or unless SSLHostValidationOn is set to False, the request will return a status 0, if the server requires SSL verification. Settng SSLHostValidationOn to false can be used for internal HTTPS URLs on servers with self-signed certs. Default value is True.",
          "name": "SSLHostValidationOn",
          "type": "Boolean"
        },
        {
          "default": "LIT_STR(\"1.0.2\")",
          "description": "Returns VSE version",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "Class for making a web request.",
      "methods": [
        {
          "description": "Adds a cookie to the WebRequest.",
          "name": "AddCookie",
          "parameters": [
            {
              "default": "",
              "description": "Cookie name",
              "name": "Name",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Cookie value",
              "name": "Value",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "WebRequest",
          "type": "Function"
        },
        {
          "description": "Adds an HTTP header for the WebRequest. Properties are available for easily setting the Authorization, Accept and Content-Type headers.",
          "name": "AddHeader",
          "parameters": [
            {
              "default": "",
              "description": "HTTP Header name",
              "name": "Name",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Value for the HTTP header",
              "name": "Value",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "WebRequest",
          "type": "Function"
        },
        {
          "description": "Base64 encodes a string, useful for manipulating body content.",
          "name": "Base64Encode",
          "parameters": [
            {
              "default": "",
              "description": "Content to base64 encode.",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Performs a synchronous download a file to a given path. If the request does not return HTTP status 200, the file will contain the body of the response.",
          "name": "FileDownload",
          "parameters": [
            {
              "default": "",
              "description": "Path to download to",
              "name": "DestinationPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "",
              "name": "Overwrite",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "WebResponse",
          "type": "Function"
        },
        {
          "description": "Performs an async download of a file. If the request does not return HTTP status 200, the file will contain the body of the response.",
          "name": "FileDownloadNoWait",
          "parameters": [
            {
              "default": "",
              "description": "Path in which to put the downloaded file",
              "name": "DestinationPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "",
              "name": "Overwrite",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "Completion",
          "type": "Function"
        },
        {
          "description": "Performs a synchronous upload of a file at a given path.",
          "name": "FileUpload",
          "parameters": [
            {
              "default": "",
              "description": "Path to file to upload",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "WebResponse",
          "type": "Function"
        },
        {
          "description": "Performs an asynchronous file upload of a file at a given path.",
          "name": "FileUploadNoWait",
          "parameters": [
            {
              "default": "",
              "description": "Path to file to upload",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Completion",
          "type": "Function"
        },
        {
          "description": "Constructor, not exposed",
          "name": "New",
          "parameters": [],
          "returnType": "WebRequest",
          "type": "Function"
        },
        {
          "description": "Submits the WebRequest, performing the curl request.",
          "name": "Send",
          "parameters": [],
          "returnType": "WebResponse",
          "type": "Function"
        },
        {
          "description": "Submits the WebRequest asynchronously, performing the curl request on another thread. This function returns immediately. Use the Completion object to determine if the request has completed, then inspect the response.",
          "name": "SendAsync",
          "parameters": [],
          "returnType": "Completion",
          "type": "Function"
        }
      ],
      "name": "WebRequest",
      "namespace": "WebVSE",
      "properties": [
        {
          "default": "LIT_STR(\"*/*\")",
          "description": "Sets \"Accept\" HTTP header with relevant value, .g. \"application/json\". Default value is \"*/\".",
          "name": "AcceptHeader",
          "type": "String"
        },
        {
          "default": "",
          "description": "Sets the \"Authorization\" HTTP header.",
          "name": "AuthorizationHeader",
          "type": "String"
        },
        {
          "default": "",
          "description": "Sets the \"Content-Type\" HTTP header, for the content type being sent in the request, e.g. \"application/json\".",
          "name": "ContentType",
          "type": "String"
        },
        {
          "default": "",
          "description": "Sets the body content for a POST / PUT / PATCH WebRequest.",
          "name": "RequestBody",
          "type": "String"
        },
        {
          "default": "",
          "description": "Sets the target URL to append to the HostURL of the WebServer. This allows multiple requests for the same base URL of the WebServer.",
          "name": "Target",
          "type": "String"
        },
        {
          "default": "0",
          "description": "Sets the numb of seconds after which to time out the WebRequest. Default is 0, for no timeout.",
          "name": "TimeoutSeconds",
          "type": "Long-Signed"
        },
        {
          "default": "LIT_STR(\"GET\")",
          "description": "Sets the HTTP verb for the request, defaulting to \"GET\".",
          "name": "Verb",
          "type": "String"
        },
        {
          "default": "False",
          "description": "Whether this Request should create a .log file with verbose logging output from libcurl. This is helpful when debugging networking issues related to VPN's, proxies, self-signed SSL certificates, etc.",
          "name": "VerboseLogging",
          "type": "Boolean"
        }
      ]
    },
    {
      "description": "Class for handling responses from web requests.",
      "methods": [
        {
          "description": "Decodes a base64-encoded string without needing to include HashVSE",
          "name": "Base64Decode",
          "parameters": [
            {
              "default": "",
              "description": "Base64-encoded string to convert",
              "name": "Input",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Constructor, not exposed",
          "name": "New",
          "parameters": [],
          "returnType": "WebResponse",
          "type": "Function"
        }
      ],
      "name": "WebResponse",
      "namespace": "WebVSE",
      "properties": [
        {
          "default": "",
          "description": "Retrieves all cookies as an array of strings, where the value is a tab-separated cookie containing seven fields: - Domain name - Include subdomains - Path - Set over a secure transport - Expires at, either seconds since Jan 1st 1970 or 0 - Name of the cookie - Value of the cookie",
          "name": "AllCookies",
          "type": "String"
        },
        {
          "default": "",
          "description": "Retrieves all HTTP headers as an array of strings, where the header is \"NAME: VALUE\"",
          "name": "AllHeaders",
          "type": "String"
        },
        {
          "default": "",
          "description": "Provides access to the response body from the WebResponse.",
          "name": "ContentBody",
          "type": "String"
        },
        {
          "default": "0",
          "description": "Provides easy access to the Content-Length HTTP header of the WebResponse. For chunked encoding, the length will be -1.",
          "name": "ContentLength",
          "type": "Long-Signed"
        },
        {
          "default": "",
          "description": "Provides easy access to the Content-Type HTTP header of the WebResponse.",
          "name": "ContentType",
          "type": "String"
        },
        {
          "default": "0",
          "description": "Provides access to the response code for the WebResponse.",
          "name": "ResponseCode",
          "type": "Integer-Signed"
        },
        {
          "default": "0",
          "description": "Provides access to the duration the WebRequest took to complete in milliseconds.",
          "name": "TransactionMicroseconds",
          "type": "Double"
        }
      ]
    },
    {
      "description": "Class for handling completion of async web file requests.",
      "methods": [
        {
          "description": "Whether or not the upload/download is complete, with an optional number of seconds to wait.",
          "name": "IsComplete",
          "parameters": [
            {
              "default": "5",
              "description": "Optional. Number of seconds to wait, defaulting to 5 if not set.",
              "name": "WaitTime",
              "optional": "True",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Constructor, not exposed",
          "name": "New",
          "parameters": [],
          "returnType": "Completion",
          "type": "Function"
        },
        {
          "description": "Waits for completion of the download / upload, taking an optional number of seconds to wait.",
          "name": "Wait",
          "parameters": [
            {
              "default": "30",
              "description": "Optional. Number of seconds to wait and then timeout, defaulting to 30 seconds if not set",
              "name": "Timeout",
              "optional": "True",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "Completion",
      "namespace": "WebVSE",
      "properties": [
        {
          "default": "0",
          "description": "Response code for the associated WebResponse.",
          "name": "CompletionCode",
          "type": "Integer-Signed"
        },
        {
          "default": "",
          "description": "The WebResponse that is the result of the download request.",
          "name": "Response",
          "type": "WebResponse"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*WebVSE\"",
  "name": "WebVSE"
}
