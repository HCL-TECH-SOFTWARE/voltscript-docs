{
  "classes": [
    {
      "description": "Represents a stream of binary or character data.",
      "methods": [
        {
          "description": "Releases the file, if any, associated with the stream. It is recommended that you close streams explicitly using this method, although they close implicitly at the end of their scope. Closing a stream with zero bytes deletes the associated file.",
          "name": "Close",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Flushes the internal buffers this stream uses. The read buffer is emptied, and the write buffer is written out to disk, then emptied.",
          "name": "Flush",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Sub"
        },
        {
          "description": "Standard constructor. A new Stream can be allocated in the standard way. When a stream is created, property values are: Bytes is 0 Charset is undefined. IsEOS is True. IsReadOnly is False. Position is 0.",
          "name": "New",
          "parameters": [],
          "returnType": "Stream",
          "type": "Function"
        },
        {
          "description": "Associates a file or standard input and output with a stream. If assocating with a file: Provide a local file path, either relative or absolute. This method creates the file if it does not exist. An error is raised if the file cannot be opened or created.  Common sources of these errors include creating a file in a directory that does not exist, opening a file you do not have permission to access, and creating a file in a read-only directory. When a stream is opened, property values are: Bytes is 0 for a new file and the number of bytes in the file for an existing file. Charset is as specified for the charset argument. Position is 0. IsEOS is True if the stream is empty, otherwise it is False. IsReadOnly is True if the file is read-only, False if the file is read-write. It is recommended that you call Close when you are finished processing the stream. Valid character sets include: Unicode, UTF-16 - Selects UTF-8 or UTF-16 LE/BE based on the BOM in the file. Defaults to UTF-16 LE. UTF-16LE, UTF-16BE - UTF-16 with Little Endian or Big Endian byte order. UTF-8 ASCII LMBCS, LMBCS10, LMBCS_OPT Platform, System - uses the default encoding of your platform This method raises an error and fails if: The path name is not valid The path name is a directory, not a file. The directory a new file is to be created in does not exist. You do not have permission to open the specified file. The stream is already open. If associating with standard input and output: Provide a character set of \"STDIO\", \"STDIN\", \"STDOUT\", or \"STDIN_STDOUT\" (case insensitive). The provided filename will be ignored. Read calls will read from standard input, write calls will write to standard output.  This can be used to read input from the user, or communicate with other processes via pipes and redirection.  Incoming text will be assumed to be in UTF-8 encoding, and outgoing text will be converted to UTF-8. When a stream is opened, property values are: Bytes is 0. Charset is the provided string. Position is 0. IsEOS is True. IsReadOnly is False. If creating an in-memory buffer: Provide a chracter set of \"MEMORY\" or \"BUFFER\". This can be useful for building a large string or for logging without writing out to a file. Write calls will append to the internal buffer, as usual. Read calls will read from it. Text will be in UTF-16 encoding. Calling Close will empty the buffer completely. This method raises an error and fails if: Parameter Charset$ is not a valid character set.",
          "name": "Open",
          "parameters": [
            {
              "default": "",
              "description": "The path name of a file, can be absolute or relative to the current working directory",
              "name": "filepath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "The character set that describes the file content",
              "name": "charset",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Reads bytes from a stream. This method starts at Position and reads the number of bytes specified or the number of bytes left in the stream.  Position is updated after calls to this method. No translation is done on the incoming bytes. Returns a variant array of bytes. The lower bound of the returned array is 0, except that if the number of bytes read is greater than 32767, the lower bound is -32768.  If the stream is empty, an empty array is returned. When a stream is read from, properties values are: Position is updated to the next unread byte. IsEOS is True if the last byte was read from the stream, and Position and Bytes have the same value.",
          "name": "ReadBytes",
          "parameters": [
            {
              "default": "65535",
              "description": "The number of bytes to read to a maximum of 65535. Defaults to the number of bytes in the stream starting at the current position, to a maximum of 65535. If the number of bytes read is greater than 32767, the lower bound is -32768.",
              "name": "length",
              "optional": "True",
              "type": "Long-Signed"
            },
            {
              "default": "30",
              "description": "Only used when the stream is reading standard input. Time, in seconds, to wait for input before returning what was read. An empty array may be returned.",
              "name": "timeout",
              "optional": "True",
              "type": "Long-Unsigned"
            }
          ],
          "returnType": "Byte",
          "type": "Function"
        },
        {
          "description": "Reads text from the stream, either one line at a time or all at once. Text is converted from the encoding specified in Charset to the internal encoding used by VoltScript. Returns the text read as a String. If oneLine is True, the EOL sequence is not included in the string. Acceptable values for eol are: EOL_ANY (4) treats any of EOL_CR, EOL_CRLF, or EOL_LF as end-of-line. EOL_CR (2) treats a carriage return (ASCII 13) as end-of-line. EOL_CRLF (0) treats a carriage return and line feed (ASCII 10 + 13) as end-of-line. EOL_LF (1) treats a line feed (ASCII 10) as end-of-line. EOL_NONE (5) treats nothing as end-of-line. EOL_PLATFORM (3) follows the conventions of the current platform - EOL_CRLF for Windows, EOL_LF for Linux. Default.",
          "name": "ReadText",
          "parameters": [
            {
              "default": "LSXFalse",
              "description": "Whether or not to read until the next EOL sequence, or the rest of the file True reads until the next EOL sequence, False reads the rest of the file to a maximum of 2 GB. Defaults to False.",
              "name": "oneLine",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "EOL_PLATFORM",
              "description": "Optional. Constant of type Long. Defaults to the current platform's standard - EOL_CRLF for Windows, EOL_LF for Linux",
              "name": "eol",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "30",
              "description": "Optional. Only used when reading from standard input. Time, in seconds, to wait before returning any input or an empty string if a new line was not read.",
              "name": "timeout",
              "optional": "True",
              "type": "Long-Unsigned"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Internal method used to register the VSE with the runtime registry.",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Deletes the contents of a stream. Raises an error if the stream is read-only. When a stream is truncated, property values are: Bytes is 0 IsEOS is True Position is 0 Closing a stream with zero bytes deletes the associated file.",
          "name": "Truncate",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Sub"
        },
        {
          "description": "Writes bytes to a stream. Appends the bytes to the end of the stream. This method raises an error if the stream is read-only. Returns the number of bytes written. When a stream is written to, property values are: Bytes is incremented by the number of bytes written IsEOS is True Position is set to the end of the stream",
          "name": "WriteBytes",
          "parameters": [
            {
              "default": "",
              "description": "Variant Array of Bytes or Shorts. The bytes to write, to a maximum number of 65535 Bytes, or 32767 Shorts.",
              "name": "buffer",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Long-Signed",
          "type": "Function"
        },
        {
          "description": "Writes a new line character to the stream. Returns the number of bytes written. Acceptable values for eol are: EOL_PLATFORM (3) follows the conventions of the current platform. Default. EOL_CRLF (0) appends a carriage return and line feed (ASCII 10 + 13). EOL_LF (1) appends a line feed (ASCII 10). EOL_CR (2) appends a carriage return (ASCII 13). EOL_NONE (5) appends nothing.",
          "name": "WriteNewLine",
          "parameters": [
            {
              "default": "EOL_PLATFORM",
              "description": "End-of-line character(s) to write to the stream. The default is EOL_PLATFORM (3).",
              "name": "eol",
              "optional": "True",
              "type": "Integer-Signed"
            }
          ],
          "returnType": "Long-Signed",
          "type": "Function"
        },
        {
          "description": "Writes text to a stream, with a EOL sequence if desired. This method raises and error if the stream is read-only.  The text will be translated to the stream's specified Charset before being written.  If the stream is opened on an empty file and the character set is Unicode, UTF-16, UTF-16LE, or UTF-16BE, a byte order mark is written at the beginning of the file.  These bytes are transparent upon subsequent ReadText method calls with the same character set, but are visible via ReadBytes. Returns the number of bytes written. When a stream is written, property values are: Bytes is incremented by the number of bytes written. IsEOS is True. Position is set at end of stream. Acceptable values for eol are: EOL_CR (2) appends a carriage return (ASCII 13). EOL_CRLF (0) appends a carriage return and line feed (ASCII 10 + 13). EOL_LF (1) appends a line feed (ASCII 10). EOL_NONE (5) appends nothing. Default. EOL_PLATFORM (3) follows the conventions of the current platform.",
          "name": "WriteText",
          "parameters": [
            {
              "default": "",
              "description": "The text to write, to a maximum of 2GB bytes",
              "name": "text",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "EOL_NONE",
              "description": "End-of-line character(s) appended to the text. The default is EOL_NONE (5)",
              "name": "eol",
              "optional": "True",
              "type": "Integer-Signed"
            }
          ],
          "returnType": "Long-Signed",
          "type": "Function"
        }
      ],
      "name": "Stream",
      "namespace": "StreamVSE",
      "properties": [
        {
          "default": "",
          "description": "Read-only. The size of the stream in bytes. This property is 0 for a new steam.  After Open is called, this is set to the actual size of the file associated with this stream,  Updating as any write or truncate operations are performed.",
          "name": "Bytes",
          "type": "Long-Signed"
        },
        {
          "default": "",
          "description": "Represents the character set used for a stream. This is set after opening a file with Open.",
          "name": "Charset",
          "type": "String"
        },
        {
          "default": "",
          "description": "Is End Of Stream. Indicates if the current position is the end of the stream.  Being at the end of the stream indicates that no data will be returned from Read calls until Position is changed. This property is True in the following cases: 1. The stream is empty - Position is the same as Bytes. 2. Open occurs on an empty stream. 3. Truncate occurs on the stream. 4. WriteBytes or WriteText occurs on the stream.",
          "name": "IsEOS",
          "type": "Boolean"
        },
        {
          "default": "False",
          "description": "If this Stream has been opened and is ready to read or write. Returns True if this Stream is open. Returns False otherwise (i.e., has not had Open called yet, trying to open a directory, has had Close called)",
          "name": "IsOpen",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "Indicates that the stream is associated with a read-only file. True if the file associated with this stream via Open is read-only. False otherwise. Write operations cannot be performed on a read-only file.",
          "name": "IsReadOnly",
          "type": "Boolean"
        },
        {
          "default": "0",
          "description": "Offset from the beginning of the stream in bytes. A value of 0 means the beginning of the stream. Can be set to change the position used for read calls. This property cannot be set to a value greater than the size of the stream (see the Bytes property) or a negative value. Settings Setting this property to the size of the stream sets the position to the end of the stream. WriteBytes and WriteText update this property to the end of the stream. Setting this property has no effect on these methods. This proptery affects ReadBytes and ReadText, and is updated by these methods to point to the next unread byte in the stream.  You should exercise care when setting a value other than 0 or Bytes. No special support exists for multibyte characters.",
          "name": "Position",
          "type": "Long-Signed"
        },
        {
          "default": "",
          "description": "The path to the library file this VSE was registered with.",
          "name": "VSEPath",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"1.0.2\")",
          "description": "Internal version number for this VSE module.",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*StreamVSE\"",
  "name": "StreamVSE"
}
