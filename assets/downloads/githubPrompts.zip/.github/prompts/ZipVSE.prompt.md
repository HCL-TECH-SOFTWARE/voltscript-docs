{
  "classes": [
    {
      "description": "ZipArchive is a collection class: iterate using \"forall\", or use a file name as an index. E.g., set ZipFileInstance = Archive(\"filename\"). Using filename as index throws error 404 if there is no matching file is in the zip archive.",
      "methods": [
        {
          "description": "Add a file to the zip archive.",
          "name": "AddFile",
          "parameters": [
            {
              "default": "",
              "description": "Path to the file to add",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Comment to assign to the file in the zip",
              "name": "Comment",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXTrue",
              "description": "Whether to add the file with the full path with which the file was retrieved",
              "name": "UseFullPath",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "ZipFile",
          "type": "Function"
        },
        {
          "description": "Add an array of files to the zip, optionally using the full path.",
          "name": "AddFileList",
          "parameters": [
            {
              "default": "",
              "description": "Directory containing the files in the FileNames argument",
              "name": "DirectoryPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Array of files to add",
              "name": "FileNames",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXTrue",
              "description": "Whether to add the file with the full path with which the file was retrieved",
              "name": "UseFullPath",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "ZipFile",
          "type": "Function"
        },
        {
          "description": "Adds all files that match a particular wildcard specification in a specific directory.",
          "name": "AddFiles",
          "parameters": [
            {
              "default": "",
              "description": "Directory from which to add files",
              "name": "DirectoryPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"*\")",
              "description": "Specification for which files to add, e.g. \"*.pdf\"",
              "name": "WildcardSpec",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXTrue",
              "description": "Whether to add the file with the full path with which the file was retrieved",
              "name": "UseFullPath",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "ZipFile",
          "type": "Function"
        },
        {
          "description": "Close the handle to the zip archive.",
          "name": "CloseArchive",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Sub"
        },
        {
          "description": "Creates a new zip archive ready for files to be addde. If you are just wanting to extract files from an existing zip, use openArchive() instead",
          "name": "CreateArchive",
          "parameters": [
            {
              "default": "",
              "description": "Path at which to create the archive",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Global comment to apply to the zip archive",
              "name": "Comment",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Whether to overwrite a zip if one already exists at the requestd filepath",
              "name": "Overwrite",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Extracts all files from a zip to a specific directory",
          "name": "ExtractAllFiles",
          "parameters": [
            {
              "default": "",
              "description": "Directory into which to extract the files",
              "name": "DestinationDirectory",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Whether to create the directory",
              "name": "CreateDirectory",
              "optional": "False",
              "type": "Boolean"
            },
            {
              "default": "",
              "description": "Whether to overwrite a file if one already exists with the same name",
              "name": "OverwriteFiles",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Finds a file within a zip archive. Triggers error 404 if file not found.",
          "name": "FindFile",
          "parameters": [
            {
              "default": "",
              "description": "Filename to look for",
              "name": "FileName",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "ZipFile",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "ZipArchive",
          "type": "Function"
        },
        {
          "description": "Opens an existing zip archive at a specified filepath.",
          "name": "OpenArchive",
          "parameters": [
            {
              "default": "",
              "description": "Filepath for the zip archive",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Internal method used to register the VSE with the runtime registry.",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "ZipArchive",
      "namespace": "ZipVSE",
      "properties": [
        {
          "default": "LIT_STR(\"\")",
          "description": "Path where the archive can be found.",
          "name": "ArchivePath",
          "type": "String"
        },
        {
          "default": "0",
          "description": "Size of the zip archive.",
          "name": "ArchiveSize",
          "type": "Long-Signed"
        },
        {
          "default": "0",
          "description": "Number of top-level entries in the zip archive. These could be files or directories.",
          "name": "EntryCount",
          "type": "Long-Signed"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "A comment assigned to the zip archive.",
          "name": "GlobalComment",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"1.0\")",
          "description": "",
          "name": "VSEVersion",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"1.2.13\")",
          "description": "The version of the C/C++ zip library in use.",
          "name": "ZipVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "A file within a zip archive",
      "methods": [
        {
          "description": "Extracts the file to a directory, with options to create the directory and overwrite the file.",
          "name": "ExtractFile",
          "parameters": [
            {
              "default": "",
              "description": "Directory into which to extract the file",
              "name": "DestinationDirectory",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Whether to create the destination directory",
              "name": "CreateDirectory",
              "optional": "False",
              "type": "Boolean"
            },
            {
              "default": "",
              "description": "Whether to overwrite if the destination includes a file with the same name. If false, the file will not be extracted.",
              "name": "OverwriteFile",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Constructor, not exposed",
          "name": "New",
          "parameters": [],
          "returnType": "ZipFile",
          "type": "Function"
        }
      ],
      "name": "ZipFile",
      "namespace": "ZipVSE",
      "properties": [
        {
          "default": "0",
          "description": "Size of the file within the zip archive when compressed.",
          "name": "CompressedSize",
          "type": "Long-Signed"
        },
        {
          "default": "",
          "description": "Comment allocated to the zip file when it was added to the zip archive.",
          "name": "FileComment",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "Name of the file.",
          "name": "FileName",
          "type": "String"
        },
        {
          "default": "False",
          "description": "Whether this \"file\" in the zip archive is a directory, which could contain files and / or directories.",
          "name": "IsDirectory",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "The zip archive this file is in.",
          "name": "ParentArchive",
          "type": "ZipArchive"
        },
        {
          "default": "0",
          "description": "Size of the file within the zip archive when uncompressed.",
          "name": "UncompressedSize",
          "type": "Long-Signed"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*ZipVSE\"",
  "name": "ZipVSE"
}
