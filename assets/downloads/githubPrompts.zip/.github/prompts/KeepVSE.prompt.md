{
  "classes": [
    {
      "description": "Class to access a Domino server that is running Domino REST API.",
      "methods": [
        {
          "description": "Initializes a KeepScope for a given scope.",
          "name": "GetScope",
          "parameters": [
            {
              "default": "",
              "description": "Name of the scope",
              "name": "ScopeName",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "KeepScope",
          "type": "Function"
        },
        {
          "description": "Return information about the currently authenticated user",
          "name": "GetUserInfo",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Logs into a Domino REST API server. There is no access to the JWT token for the session, for security purposes.",
          "name": "Login",
          "parameters": [
            {
              "default": "",
              "description": "Username with which to login",
              "name": "User",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Password with which to login",
              "name": "Password",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Logs out the current user from the Domino REST API server, invalidating the JWT token.",
          "name": "Logout",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "KeepServer",
          "type": "Function"
        },
        {
          "description": "",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "KeepServer",
      "namespace": "KeepVSE",
      "properties": [
        {
          "default": "",
          "description": "Scopes available in the \"scope\" property of the JWT token, where each scope is separate by a space. E.g. \"MAIL $DATA $DECRYPT\".",
          "name": "AccessScopes",
          "type": "String"
        },
        {
          "default": "",
          "description": "Path for certificate to use when connecting to the server.",
          "name": "CertificatePath",
          "type": "String"
        },
        {
          "default": "False",
          "description": "Whether server is logged in as a user.",
          "name": "Connected",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "The version of Domino the server is currently running, as reported by DRAPI.",
          "name": "DominoVersion",
          "type": "String"
        },
        {
          "default": "",
          "description": "The version of the Domino REST API (DRAPI) currently running on the remote server, as reported by DRAPI.",
          "name": "DRAPIVersion",
          "type": "String"
        },
        {
          "default": "",
          "description": "The JWT token string (encrypted and Base-64 encoded) used to log in to the Keep server. The property will be set automatically if a token is provided in the script invocation, or when the script sucessfully executes a KeepServer.Login call.",
          "name": "JWTToken",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "the version of LibCurl used in this vse",
          "name": "LibCurlVersion",
          "type": "String"
        },
        {
          "default": "",
          "description": "A String Array of rich text processors (plain, MIME, Markdown, etc.) supported by the server. This list is fetched from the server if it has not been accessed yet in the script.",
          "name": "RichTextProcessors",
          "type": "String"
        },
        {
          "default": "",
          "description": "JSON array of scopes that can be requested, equivalent to /scopes GET endpoint. ",
          "name": "ScopeList",
          "type": "String"
        },
        {
          "default": "",
          "description": "Information about the Domino REST API server, equivalent tothe response from /admin/info GET endpoint.",
          "name": "ServerInfo",
          "type": "String"
        },
        {
          "default": "",
          "description": "Base URL for Domino REST API calls, protocol + server + \"api/v1\", e.g. \"http://localhost:8880/api/v1\" to connect to a locally running Domino server.",
          "name": "ServerURL",
          "type": "String"
        },
        {
          "default": "False",
          "description": "Whether this Server should create a .log file with verbose logging output from libcurl when a request to the DRAPI server is made. This is helpful when debugging networking issues related to VPN's, proxies, self-signed SSL certificates, etc.",
          "name": "VerboseLogging",
          "type": "Boolean"
        },
        {
          "default": "LIT_STR(\"1.0\")",
          "description": "Internal method only",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "Class to access a scope exposed from Domino REST API.",
      "methods": [
        {
          "description": "",
          "name": "BulkCreate",
          "parameters": [
            {
              "default": "",
              "description": "JSON array of document properties",
              "name": "JSONInput",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Delete a list of Documents. Status of each deletion is returned.",
          "name": "BulkDelete",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "UNIDList",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "",
          "name": "BulkGet",
          "parameters": [
            {
              "default": "",
              "description": "Array of UNIDs to fetch",
              "name": "UNIDList",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "The format rich text should be returned as. Default: \"mime\". Default options: \"mime\", \"html\", \"plain\", \"markdown\".",
              "name": "RichTextAs",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXTrue",
              "description": "When set to false, all metadata Json items on the top level of an object get suppressed. Default is true",
              "name": "WithMeta",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "Form mode to use. Default: \"default\".",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Performs a DQL query updating selected items in the documents, optionally returning a JSON string of the result. Equivalent to /bulk/update POST endpoint.",
          "name": "BulkUpdate",
          "parameters": [
            {
              "default": "",
              "description": "JSON string query used to identify documents to update, corresponding to content of \"query\" item passed in Domino REST API request body",
              "name": "DQLQuery",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Maximum number of documents to scan",
              "name": "MaxScan",
              "optional": "False",
              "type": "Long-Signed"
            },
            {
              "default": "",
              "description": "Whether to use views when performing DQL query",
              "name": "UseViews",
              "optional": "False",
              "type": "Boolean"
            },
            {
              "default": "",
              "description": "JSON string of items to replace, corresponding to content of \"replaceItems\" item passed in Domino REST API request body",
              "name": "ReplaceItems",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "Form Access Mode to use when updating documents",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "Whether to return document content for updated documents or just a summary status update JSON object of documents upated",
              "name": "ReturnUpdates",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Creates a KeepDocument, loading it with a JSON string corresponding to what Domino REST API expects for the default mode for the given form. NOTE:  This does not make a call to Domino REST API, it just creates an in-memory VoltScript object ready to be sent to Domino REST API.",
          "name": "CreateDocument",
          "parameters": [
            {
              "default": "LIT_STR(\"\")",
              "description": "String corresponding to the data to be passed to Domino REST API",
              "name": "JSONValue",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "KeepDocument",
          "type": "Function"
        },
        {
          "description": "Create a new ProfileDocument",
          "name": "CreateProfileDocument",
          "parameters": [
            {
              "default": "",
              "description": "Profile name or first-level key",
              "name": "ProfileKey1",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Required form name",
              "name": "ProfileForm",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Optional second-level key",
              "name": "ProfileKey2",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "If TRUE, omit Key2, user name is the key",
              "name": "ProfileKeyIsUser",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "KeepProfileDocument",
          "type": "Function"
        },
        {
          "description": "Deletes a document passig the KeepDocument object. Equivalent to /document/{unid} DELETE endpoint, extracting the relevant UNID from the KeepDocument passed.",
          "name": "DeleteDocument",
          "parameters": [
            {
              "default": "",
              "description": "KeepDocument to be deleted",
              "name": "Document",
              "optional": "False",
              "type": "KeepDocument"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Form Access Mode with which to delete the document",
              "name": "FormMode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Deletes a document passing its UNID and Form Access mode with which to delete the document. Equivalent to /document/{unid} DELETE endpoint.",
          "name": "DeleteDocumentByID",
          "parameters": [
            {
              "default": "",
              "description": "UNID of the document to delete",
              "name": "UNID",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Form Access Mode with which to delete the document",
              "name": "FormMode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Performs a DQL query returning a JSON string of the result. Equivalent to /query POST endpoint.",
          "name": "DQLQuery",
          "parameters": [
            {
              "default": "",
              "description": "String query corresponding to the request body sent to the /query POST endpoint",
              "name": "JSONQuery",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"execute\")",
              "description": "Action to perform - \"execute\", \"explain\" or \"parse\"",
              "name": "ActionType",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "0",
              "description": "Maximum number of documents to return",
              "name": "MaxCount",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "0",
              "description": "Nth document to start from when returning documents",
              "name": "StartAt",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "LIT_STR(\"html\")",
              "description": "The format rich text should be returned as. Default: \"html\". Options: \"mime\", \"html\", \"plain\", \"markdown\".",
              "name": "RichTextAs",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Compile and execute a Notes @function formula, with optional document context. Returns a JSON result",
          "name": "Evaluate",
          "parameters": [
            {
              "default": "",
              "description": "The Notes @function formula to evaluate",
              "name": "Formula",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Optional UNID of document context. If you use this argument, do not specify a DocumentQuery argument.",
              "name": "DocumentUNID",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Option DQL query to select context document. If you use this option, do not specify an UNID argument",
              "name": "DocumentQuery",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Add a list of documents to an existing folder ",
          "name": "FolderAddDocuments",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "FolderName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "List of document UNIDs to add to the folder",
              "name": "UNIDList",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "Mode to use, \"default\" if missing",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Remove a list of documents from a folder (does not delete the documents)",
          "name": "FolderRemoveDocuments",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "FolderName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Array of document UNIDs to be removed",
              "name": "UNIDList",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "Mode to use, \"default\" if missing",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns a JSON string containing information about the agents exposed in the Domino REST API schema associated with this scope.  Equivalent to the \"agents\" object from /scope GET endpoint.",
          "name": "GetAllAgents",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns a JSON string containing information about the Forms and Form Access Modes exposed in the Domino REST API schema associated with this scope.  Equivalent to the \"forms\" object from /scope GET endpoint.",
          "name": "GetAllForms",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns a JSON string containing information of all lists exposed by the Domino REST API schema associated with this scope. Equivalent of /lists GET endpoint.",
          "name": "GetAllLists",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Retrieves a document and loads it into a KeepDocument object. Equivalent to /document/{unid} GET endpoint.",
          "name": "GetDocument",
          "parameters": [
            {
              "default": "",
              "description": "UNID of the document to retrieve",
              "name": "UNID",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"html\")",
              "description": "The format rich text should be returned as. Default: \"html\". Options: \"mime\", \"html\", \"plain\", \"markdown\".",
              "name": "RichTextAs",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "Whether default value, input translation and inpiut validation formulas should be run when retrieving the document",
              "name": "ComputeWithForm",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LSXFalse",
              "description": "Whether to include meta information (noteid, unid,created etc plus warnings)",
              "name": "IncludeMeta",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "Mode with which to get document",
              "name": "FormMode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "KeepDocument",
          "type": "Function"
        },
        {
          "description": "Gets Form Access Modes for a given document, based on the FormName defined in the document. Equivalent to /documentmodes/{unid} GET endpoint.",
          "name": "GetDocumentModes",
          "parameters": [
            {
              "default": "",
              "description": "UNID of document for which to check Form Access Modes",
              "name": "UNID",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets a JSON string corresponding to the configuration for a specific Form. Equivalent to the corresponding form object from the /scope GET endpoints.",
          "name": "GetFormInfo",
          "parameters": [
            {
              "default": "",
              "description": "Form name for which to return information",
              "name": "FormName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Access mode to request for the form. Optional.",
              "name": "mode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets a JSON string corresponding to top-level category data from the list (view). If the view is not categorized, it returns entries.  Equivalent to /lists/{name} GET endpoint where scope is \"categories\".",
          "name": "GetListCategories",
          "parameters": [
            {
              "default": "",
              "description": "Name or alias of view to access",
              "name": "ViewName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Maximum number of categories, 0 to include all",
              "name": "MaxCount",
              "optional": "False",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets a JSON string corresponding to view entries or documents from the list (view). Equivalent to /lists/{name} GET endpoint where scope is \"all\".",
          "name": "GetListEntries",
          "parameters": [
            {
              "default": "",
              "description": "Name or alias of view to access",
              "name": "ViewName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "0",
              "description": "Maximum number of entries to return or 0 for all",
              "name": "MaxCount",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "LSXFalse",
              "description": "If false, returns just view entry data. If true, retrieves the document using the \"default\" mode. NOTE: If the form is configured with default mode, nothing will show with FullDocuments=True",
              "name": "FullDocuments",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Alternate column name to sort on, as configured in Domino REST API",
              "name": "SortColumn",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Key for entry to start with, corresponding to first sorted column value",
              "name": "StartsWith",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "0",
              "description": "Entry to start at, starting at 0",
              "name": "StartAt",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "LSXTrue",
              "description": "Whether sorting should be ascending or descending",
              "name": "SortAscending",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "The access mode for documents in the scope",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "If True, return all metadata with each document. Imposes a slight performance hit.",
              "name": "AllMeta",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Gets a JSON string corresponding to view entries or documents within the relevant category/categories from the list (view).  Equivalent to /lists/{name} GET endpoint where a key is passed.",
          "name": "GetListEntriesByKey",
          "parameters": [
            {
              "default": "",
              "description": "Name or alias of view to access",
              "name": "ViewName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "String or String Array. Array of keys corresponding to category, sub-category etc",
              "name": "ColumnKeys",
              "optional": "False",
              "type": "Variant"
            },
            {
              "default": "0",
              "description": "Maximum number of entries to return or 0 for all",
              "name": "MaxCount",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "LSXFalse",
              "description": "If false, returns just view entry data. If true, retrieves the document using the \"default\" mode. NOTE: If the form is configured with default mode, nothing will show with FullDocuments=True",
              "name": "FullDocuments",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "0",
              "description": "Entry to start within the category, starting at 0",
              "name": "StartAt",
              "optional": "True",
              "type": "Integer-Unsigned"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Alternate column name to sort on, as configured in Domino REST API",
              "name": "SortColumn",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXTrue",
              "description": "Whether sorting should be ascending or descending",
              "name": "SortAscending",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LIT_STR(\"default\")",
              "description": "Access mode for documents in the scope",
              "name": "Mode",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "If true, all document metadata is returned. Imposes a slight performance hit.",
              "name": "AllMeta",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Not yet implemented",
          "name": "GetListInfo",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ViewName",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Computes min, max, count, total of retrieved view entries for the given view. Returns a String in JSON format.",
          "name": "GetListPivot",
          "parameters": [
            {
              "default": "",
              "description": "Name of the view or folder.",
              "name": "viewName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Name of the column to provide the data for the pivot aggregator",
              "name": "pivotColumn",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "NULL",
              "description": "A String or String Array. Useful for categorized or sorted lists. Limits return values to entries matching the key or keys. Use multiple key parameter items to specify multiple keys in request URL. The keys specified must be in the same order as the sorted columns from left to right. Unsorted columns will be ignored.",
              "name": "keys",
              "optional": "True",
              "type": "Variant"
            },
            {
              "default": "0",
              "description": "How many entries shall be returned, default = Integer.MaxInteger (4294967295)",
              "name": "count",
              "optional": "True",
              "type": "Long-Unsigned"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "What shall the view return: document entries, category names, or all.",
              "name": "scope",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "0",
              "description": "At which entry should return values start. Default 0.",
              "name": "start",
              "optional": "True",
              "type": "Long-Unsigned"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Column for alternative sorting. This requires the list to be designed for indexing on this column.",
              "name": "sortColumn",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "The direction for alternative sorting. Options are \"asc\" for asecnding and \"desc\" for descending. This is ignored unless \"sortColum\" query parameter is passed as well. This requires the list to be designed for indexing on this column in the desired direction. Defaults to ascending if column is set.",
              "name": "sortOrder",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "A character combination to perform a partial match to identify a starting point. The character combination will be applied to the \"column\" and \"direction\" passed in the query string. This cannot be combined with the \"keys\" parameter, i.e. you cannot filter on keys and startwith within that key.",
              "name": "startsWith",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Document mode to retrieve the documents with. Current user must qualify for specfied mode.",
              "name": "mode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Retrieve a profile document. If document doesn't exist, it is created",
          "name": "GetProfileDocument",
          "parameters": [
            {
              "default": "",
              "description": "Usually the profile \"name\"",
              "name": "ProfileKey1",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Second-level key for the profile document. Optional",
              "name": "ProfileKey2",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "If True, logged in user name is used as the second key. Optional.",
              "name": "Key2IsUser",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "KeepProfileDocument",
          "type": "Function"
        },
        {
          "description": "",
          "name": "GetProfileList",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "ProfileKey1",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "ProfileKey2",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "",
              "name": "Key2IsUser",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Send a DQL query and get JSON QRP (Query Results Processor) results back. Returns a String in JSON format. This method will be updated with a new scheme for columns soon.",
          "name": "GetQueryResultsProcessor",
          "parameters": [
            {
              "default": "",
              "description": "DQL query to run. ",
              "name": "query",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Columns to extract from the queried documents. Every three entries represents a column, specifying in order: name, sort method (ascending or descending), and categorized (true or false).",
              "name": "columns",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "0",
              "description": "How many entries shall be returned, default = Integer.MaxInteger (4294967295)",
              "name": "count",
              "optional": "True",
              "type": "Long-Unsigned"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "This is form mode configured in Domino REST API for a database. If no mode has been passed, it will use default \"dql\".",
              "name": "mode",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "500000",
              "description": "Specifies the maximum allowable number of documents scanned across all query terms. DQL execution returns an error when exceeded. Default is 500,000.",
              "name": "maxScanDocs",
              "optional": "True",
              "type": "Long-Unsigned"
            },
            {
              "default": "200000",
              "description": "Specifies the maximum allowable number of view entries scanned across all query terms. DQL execution return an error when exceeded. Default is 200,000.",
              "name": "maxScanEntries",
              "optional": "True",
              "type": "Long-Unsigned"
            },
            {
              "default": "300",
              "description": "Specifies the maximum allowable seconds a DQL query is allowed to run. DQL execution returns an error when exceeded. Default is 300 (5 minutes).",
              "name": "timeoutSecs",
              "optional": "True",
              "type": "Long-Unsigned"
            },
            {
              "default": "LSXFalse",
              "description": "Return the document UNID in results instead of the note ID.",
              "name": "returnUNID",
              "optional": "True",
              "type": "Boolean"
            },
            {
              "default": "LSXFalse",
              "description": "Return the replica ID in results instead of the DB file path",
              "name": "returnReplicaID",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Constructor, not exposed",
          "name": "New",
          "parameters": [],
          "returnType": "KeepScope",
          "type": "Function"
        },
        {
          "description": "Runs an agent for a given name. NOTE: only agents with certain triggers can be run outside of a Notes Client.",
          "name": "RunAgent",
          "parameters": [
            {
              "default": "",
              "description": "Name of the agent",
              "name": "AgentName",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Runs an existing agent, serverside, passing an UNID of a document to act upon. NotesSession.documentContext can be used in the agent to access the relevant document. Existing limits of agent execution duration apply. This should only be used for short-running agents and simulated calling the agent from a browser. Returns the server's response in JSON format.",
          "name": "RunAgentWithContext",
          "parameters": [
            {
              "default": "",
              "description": "An array of UNIDs, each unid will be executed by the agent. NOTE : NotesSession.documentContext must be used in the agent to access the relevant document.",
              "name": "unids",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "The agentName in the given database. ",
              "name": "agentName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "The mode configured in Domino REST API.",
              "name": "returnMode",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "KeepScope",
      "namespace": "KeepVSE",
      "properties": [
        {
          "default": "",
          "description": "Retrieves the full JSON for the scope, the equivalent of the object returned from the /scope GET endpoint.",
          "name": "JsonValue",
          "type": "String"
        },
        {
          "default": "",
          "description": "The name of the scope requested.",
          "name": "Name",
          "type": "String"
        },
        {
          "default": "",
          "description": "Provides access to the KeepServer from which the scope was created.",
          "name": "Parent",
          "type": "KeepServer"
        }
      ]
    },
    {
      "description": "Class corresponding to a document returned by from Domino REST API.",
      "methods": [
        {
          "description": "Creates an attachment in a field in a KeepDocument. The KeepDocument needs to be retrieved from or already saved to Domino REST API.  This can be verified because UNID property will have been set. The return value is a JSON string confirming successful upload or failure.",
          "name": "CreateAttachment",
          "parameters": [
            {
              "default": "",
              "description": "Filepath of file to attach",
              "name": "SourceFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Name of item into which to attach the file",
              "name": "AttachField",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Remove the attachment for the document. Returns the server's response in JSON format.",
          "name": "DeleteAttachment",
          "parameters": [
            {
              "default": "",
              "description": "Name of the attachment to delete.",
              "name": "attachmentName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Name of the field in which the attachment resides. Pass this to remove the hotspot for the attachment from that rich text field, otherwise the hotspot will remain. If the attachment is attached directly to the document, not a field, there is not need to do this.",
              "name": "fieldName",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Not yet implemented",
          "name": "DownloadAttachment",
          "parameters": [
            {
              "default": "",
              "description": "Name of attachment to download",
              "name": "AttachmentName",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Name of attachment file to create",
              "name": "DestinationFile",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Whether to overwrite",
              "name": "Overwrite",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Retrieve a JSON array containing the names of all attachments on the current KeepDocument. The names can be used in KeepDocument.DownloadAttachment to retrieve attachments.",
          "name": "GetAttachmentNames",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns RichText in the format specfied. Built-in formats are plain, mime, html, markdown. Check KeepServer.RTProcessors to get the formats supported by the server. An error is raised if the requested format is not available.",
          "name": "GetRichText",
          "parameters": [
            {
              "default": "",
              "description": "The format to retrun the RichText as. Built-in formats are plain, mime, html, markdown.",
              "name": "RTProcessor",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Name of the RichText item to retrieve. When omitted \"Body\" is used as item name",
              "name": "ItemName",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Retrieve a value from a KeepDocument item",
          "name": "GetValue",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Variant",
          "type": "Function"
        },
        {
          "description": "Constructor, not exposed.",
          "name": "New",
          "parameters": [],
          "returnType": "KeepDocument",
          "type": "Function"
        },
        {
          "description": "Replace a document item's value with the given value. If the item doesn't exist, it is inserted. ",
          "name": "ReplaceValue",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Label",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "",
              "name": "Value",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "Variant",
          "type": "Sub"
        },
        {
          "description": "Commits updates on the KeepDocument to the Domino REST API.  Equivalent to /document POST endpoint for a document without an UNID, or to /document/{unid} PUT endpoint.",
          "name": "Save",
          "parameters": [
            {
              "default": "LIT_STR(\"\")",
              "description": "Form Access Mode with which to save the document. The mode is ignred when creating documents, because documents can only be created at \"default\" mode",
              "name": "FormMode",
              "optional": "True",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "UNID of a parent document, used to make this a response or respose-to-response",
              "name": "ParentUNID",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Sub"
        }
      ],
      "name": "KeepDocument",
      "namespace": "KeepVSE",
      "properties": [
        {
          "default": "False",
          "description": "Whether or not the current mode will implement computeWithForm when saved. NOTE: computeWithForm is configured by the Domino developer in Domino REST API on the Form Access Mode.  It is not an option available to consumers of the API because it will impact the resulting data in Domino.",
          "name": "ComputedWithForm",
          "type": "Boolean"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "",
          "name": "JSONValue",
          "type": "String"
        },
        {
          "default": "",
          "description": "Document metadata, including the form name.",
          "name": "MetaData",
          "type": "String"
        },
        {
          "default": "",
          "description": "",
          "name": "ParentScope",
          "type": "KeepScope"
        },
        {
          "default": "LIT_STR(\"\")",
          "description": "All items are returned or updated, no item name normalization or translation is applied. No schema to normalize or filter the document is applied. JSON is returned or written as-is. To be able to use this endpoint a form mode \"raw\" must exist for the value of \"form\" item in the document and the current user needs the permission (set by formula in the \"raw\" mode) to use the mode Use on your own risk!",
          "name": "Raw",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"HTML\")",
          "description": "",
          "name": "RTFormat",
          "type": "String"
        },
        {
          "default": "",
          "description": "",
          "name": "UNID",
          "type": "String"
        },
        {
          "default": "False",
          "description": "",
          "name": "WithMeta",
          "type": "Boolean"
        }
      ]
    },
    {
      "description": "Child of KeepDocument, specialized for ProfileDocuments",
      "methods": [
        {
          "description": "",
          "name": "DeleteProfile",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "KeepProfileDocument",
          "type": "Function"
        },
        {
          "description": "",
          "name": "Save",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "KeepProfileDocument",
      "namespace": "KeepVSE",
      "properties": [
        {
          "default": "",
          "description": "A form field is required on all ProfileDocuments",
          "name": "ProfileFormName",
          "type": "String"
        },
        {
          "default": "",
          "description": "Second-level key for profile document. If you want to use the logged in user name as the key, set ProfileKeyIsUser to TRUE and leave this property empty",
          "name": "ProfileKey",
          "type": "String"
        },
        {
          "default": "False",
          "description": "If TRUE, the second-level key for the document is the logged in user name",
          "name": "ProfileKeyIsUser",
          "type": "Boolean"
        },
        {
          "default": "",
          "description": "First-level key for the profile document. Required",
          "name": "ProfileName",
          "type": "String"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*KeepVSE\"",
  "name": "KeepVSE"
}