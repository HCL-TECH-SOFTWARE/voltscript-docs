{
  "classes": [
    {
      "description": "Class for interacting with OS elements.",
      "methods": [
        {
          "description": "Gets an environment variable. OSUtils uses a snapshot of environment variables that is separate to the snapshot used by the core runtime.  So if you set an environment variable using OSUtils, you must use OSUtils to retrieve the updated value.",
          "name": "GetEnvironment",
          "parameters": [
            {
              "default": "",
              "description": "Environment variable",
              "name": "EnvVar",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Used for standard files only, simple functionality. Dir can loop through files using additional calls to Dir(),  but won't work if you make a call within the loop to Dir() with a different path - i.e. to check a file exists.",
          "name": "GetFilesInDir",
          "parameters": [
            {
              "default": "",
              "description": "Path to directory, e.g. /temp/foo",
              "name": "DirPath",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Mask to match filenames. Asterisk (*) for either the filename or extension designates all files with any character in that position. Question mark (?) designates a single character in that position.",
              "name": "FileSpec",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Returns the size of the file, if it exists. Error if it does not exist. ",
          "name": "GetFileSize",
          "parameters": [
            {
              "default": "",
              "description": "Path to file",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Double",
          "type": "Function"
        },
        {
          "description": "Checks whether a directory at the path expected",
          "name": "IsDirectory",
          "parameters": [
            {
              "default": "",
              "description": "Path for directory expected, e.g. /temp/foo",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks whether a file exists at the path",
          "name": "IsFile",
          "parameters": [
            {
              "default": "",
              "description": "Path to file, e.g. /temp/foo/foo.bss",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks whether current user has write permissons to a directory or file",
          "name": "IsWritable",
          "parameters": [
            {
              "default": "",
              "description": "Path for directory or file expected, e.g. /temp/foo",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Conditionally attempts to create a directory in the filesystem. \t Checks for the existence of a directory, and if it does not exist attempts to create it.    Multiple level directories are supported.  \t @return Flag indicating success / failure. True indicates either the directory already exists or was successfully created.",
          "name": "MakeDirectories",
          "parameters": [
            {
              "default": "",
              "description": "Path to create directory, e.g. /temp/foo/bar.   ",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "OSUtils",
          "type": "Function"
        },
        {
          "description": "",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Removes a directory and potentially all files within it.   ",
          "name": "RemoveDir",
          "parameters": [
            {
              "default": "",
              "description": "Path to directory",
              "name": "Path",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LSXFalse",
              "description": "Flag indicating whether to remove all files / subfolders in the directory first.  Defaults to FALSE if not included. ",
              "name": "Force",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Sets an environment variable, returning success / failure. OSUtils uses a snapshot of environment variables that is separate to the snapshot used by the core runtime.  So if you set an environment variable using OSUtils, you must use OSUtils to retrieve the updated value.",
          "name": "SetEnvironment",
          "parameters": [
            {
              "default": "",
              "description": "Environment variable to set",
              "name": "EnvVar",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Value to set for environment variable",
              "name": "Value",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "OSUtils",
      "namespace": "OSUtilsVSE",
      "properties": [
        {
          "default": "",
          "description": "Get the user's home directory, HOME environment variable on Linux, USERPROFILE on Windows.",
          "name": "HomeDir",
          "type": "String"
        },
        {
          "default": "",
          "description": "\"W64\" or \"LINX\", calling and returning the value from getThreadInfo(13).",
          "name": "Platform",
          "type": "String"
        },
        {
          "default": "",
          "description": "Gets the temp directory for the operating system.",
          "name": "TempDir",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"1.0\")",
          "description": "Internal method only",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    },
    {
      "description": "Class for building up and returning paths.",
      "methods": [
        {
          "description": "Adds a single directory or a path to the end of the existing Path object. Returns itself for fluid coding",
          "name": "AddToPath",
          "parameters": [
            {
              "default": "",
              "description": "String for path to add, e.g. /temp/foo, or directory, e.g. foo",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "PathUtils",
          "type": "Function"
        },
        {
          "description": "Retrieves an array where each element is a directory",
          "name": "GetDirectories",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "PathUtils",
          "type": "Function"
        },
        {
          "description": "Builds the elements into a string, using the path separator as defined in the current OS",
          "name": "ToString",
          "parameters": [],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "PathUtils",
      "namespace": "OSUtilsVSE",
      "properties": []
    }
  ],
  "description": "Implement with UseVSE \"*OSUtilsVSE\"",
  "name": "OSUtilsVSE"
}
