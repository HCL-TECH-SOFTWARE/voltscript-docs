{
  "classes": [
    {
      "description": "",
      "methods": [
        {
          "description": "",
          "name": "New",
          "parameters": [],
          "returnType": "Context",
          "type": "Function"
        },
        {
          "description": "",
          "name": "RegisterVSEPath",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        }
      ],
      "name": "Context",
      "namespace": "ContextVSE",
      "properties": [
        {
          "default": "",
          "description": "Property used to retrieve any content passed to VoltScript runtime via --context flag.",
          "name": "Context",
          "type": "String"
        },
        {
          "default": "LIT_STR(\"1.0\")",
          "description": "",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*ContextVSE\"",
  "name": "ContextVSE"
}
