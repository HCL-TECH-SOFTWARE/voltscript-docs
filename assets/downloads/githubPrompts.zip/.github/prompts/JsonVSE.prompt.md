{
  "classes": [
    {
      "description": "Object for holding JSON objects, JSON arrays or scalars",
      "methods": [
        {
          "description": "For JsonObjects that are arrays, appends a value to the array. For new JsonObjects, it appends the value to the array and defines it as an array. Returns the current JsonObject instance for fluid coding.",
          "name": "AppendToJSONArray",
          "parameters": [
            {
              "default": "",
              "description": "Value to add to the array",
              "name": "Value",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Finds a JsonObject within the current JsonObject using an array of labels to navigate down the hierarchy.",
          "name": "FindObjectByPath",
          "parameters": [
            {
              "default": "",
              "description": "Array of labels to use to find the JsonObject",
              "name": "Labels",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Deprecated: use getChildren() instead.",
          "name": "GetArrayValues",
          "parameters": [],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Gets a child from the current JsonObject using its label. Returns an error 404 if the child JsonObject cannot be found.",
          "name": "GetChild",
          "parameters": [
            {
              "default": "",
              "description": "Label of child",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Gets all the children of the current JsonObject, as an array of JsonObjects. Only valid is the JsonObject is an object or an array.",
          "name": "GetChildren",
          "parameters": [],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Retrieves a descendent JSONObject from another JSONObject using a specified path to the child object. ",
          "name": "GetDescendantPath",
          "parameters": [
            {
              "default": "",
              "description": "Delimited path to the desired item",
              "name": "Path",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"/\")",
              "description": "Character used as a delimiter in Path. Defaults to \"/\"",
              "name": "Delimiter",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Inserts another JsonObject into an existing JsonObject, with an optional label. If no label is provided, the label of the JsonObject is used. Returns the current JsonObject instance for fluid coding.",
          "name": "InsertObject",
          "parameters": [
            {
              "default": "",
              "description": "JsonObject to insert",
              "name": "Object",
              "optional": "False",
              "type": "JSONObject"
            },
            {
              "default": "LIT_STR(\"\")",
              "description": "Label to use when inserting",
              "name": "Label",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Inserts a value into a JsonObject using th label defined. Returns the current JsonObject instance for fluid coding.",
          "name": "InsertValue",
          "parameters": [
            {
              "default": "",
              "description": "Label to insert as",
              "name": "Label",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "",
              "description": "Value to add, either a scalar or another JsonObject",
              "name": "Value",
              "optional": "False",
              "type": "Variant"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Returns whether or not a given JsonObject is an array.",
          "name": "IsArray",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns whether or not a JsonObject is a boolean.",
          "name": "IsBoolean",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns whether or not the JsonObject has a child with the specified label.",
          "name": "IsChild",
          "parameters": [
            {
              "default": "",
              "description": "Label within this JsonObject",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Checks if there is a JsonObject within the current JsonObject, using an array of labels to navigate down the hierarchy.",
          "name": "IsDescendant",
          "parameters": [
            {
              "default": "",
              "description": "Array of labels to use to check for the JsonObject",
              "name": "Path",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "",
          "name": "IsDescendantPath",
          "parameters": [
            {
              "default": "",
              "description": "",
              "name": "Path",
              "optional": "False",
              "type": "String"
            },
            {
              "default": "LIT_STR(\"/\")",
              "description": "",
              "name": "Delimiter",
              "optional": "True",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns TRUE if the current JsonObject has a null value",
          "name": "IsNull",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns whether or not a JsonObject is a number.",
          "name": "IsNumber",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns whether or not a JsonObject is an object.",
          "name": "IsObject",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns whether or not a JsonObject is a scalar value (string, number, boolean).",
          "name": "IsScalar",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Returns whether or not a JsonObject is a string.",
          "name": "IsString",
          "parameters": [],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [
            {
              "default": "LSXFalse",
              "description": "If IsArray is T, creates an empty array object ([]), otherwise an empty JSON object ({})",
              "name": "IsArray",
              "optional": "True",
              "type": "Boolean"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "For a JsonObject that is an array, remove the array entry at the provided index (0 being the first entry)",
          "name": "RemoveArrayEntry",
          "parameters": [
            {
              "default": "",
              "description": "The position in the array (0-based) of the entry to remove",
              "name": "Index",
              "optional": "False",
              "type": "Integer-Unsigned"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Removes a child from a JsonObject.",
          "name": "RemoveChild",
          "parameters": [
            {
              "default": "",
              "description": "Label of the child to remove",
              "name": "Label",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Converts a JsonObject to a string, either pretty-printed or as compact JSON.",
          "name": "toString",
          "parameters": [
            {
              "default": "",
              "description": "Whether or not to pretty-print",
              "name": "PrettyPrint",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "JSONObject",
      "namespace": "JsonVSE",
      "properties": [
        {
          "default": "",
          "description": "Number of child elements within this JsonObject.",
          "name": "ChildCount",
          "type": "Integer-Unsigned"
        },
        {
          "default": "",
          "description": "Type of the JsonObject as a string. Useful for logging. To check the JsonObject type in conditionals use the corresponding is... methods. Values are: - string - number - array - boolean - object",
          "name": "JSONType",
          "type": "String"
        },
        {
          "default": "",
          "description": "Label for the JsonObject, blank for a JsonObject that is an array.",
          "name": "Label",
          "type": "String"
        },
        {
          "default": "",
          "description": "JsonObject that contains this JsonObject, if available.",
          "name": "ParentObject",
          "type": "JSONObject"
        },
        {
          "default": "NULL",
          "description": "String, number or boolean value of this JsonObject. Only valid for JsonObjects where isScalar is true. Not valid for arrays or objects.",
          "name": "ScalarValue",
          "type": "Variant"
        },
        {
          "default": "",
          "description": "First 16 characters of the toString() value of this JsonObject. Useful for debugging or logging purposes to easly identify the current JsonObject from a larger string of JSON.",
          "name": "ShortValue",
          "type": "String"
        },
        {
          "default": "",
          "description": "Only valid for a JsonObject that contains an array of scalars. Returns a Variant array of the values.",
          "name": "ValueArray",
          "type": "Variant"
        }
      ]
    },
    {
      "description": "Class for parsing strings and files of JSON.",
      "methods": [
        {
          "description": "Gets the parsed JSON as a JsonObject.",
          "name": "GetRootObject",
          "parameters": [],
          "returnType": "JSONObject",
          "type": "Function"
        },
        {
          "description": "Returns True if the input is valid JSON, otherwise returns False",
          "name": "IsValidJSON",
          "parameters": [
            {
              "default": "",
              "description": "String to validate",
              "name": "JSON",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "Boolean",
          "type": "Function"
        },
        {
          "description": "Reads a file and parses it as JSON.",
          "name": "LoadFromFile",
          "parameters": [
            {
              "default": "",
              "description": "File consisting of JSON.",
              "name": "FilePath",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "JSONParser",
          "type": "Function"
        },
        {
          "description": "Parses a string of JSON. If the string passed is not valid JSON, th method throws an error 400, \"JSON text is not valid\".",
          "name": "LoadFromJSON",
          "parameters": [
            {
              "default": "",
              "description": "String of JSON to parse",
              "name": "JSON",
              "optional": "False",
              "type": "String"
            }
          ],
          "returnType": "JSONParser",
          "type": "Function"
        },
        {
          "description": "Parses a JSON object from a passed JsonObject.",
          "name": "LoadFromObject",
          "parameters": [
            {
              "default": "",
              "description": "JsonObject to pass through the parser",
              "name": "Object",
              "optional": "False",
              "type": "JSONObject"
            }
          ],
          "returnType": "JSONParser",
          "type": "Function"
        },
        {
          "description": "Constructor",
          "name": "New",
          "parameters": [],
          "returnType": "JSONParser",
          "type": "Function"
        },
        {
          "description": "Outputs the root object of a JsonParser as a string, pretty-printed or compact.",
          "name": "ToString",
          "parameters": [
            {
              "default": "",
              "description": "Whether or not to pretty-print the JSON",
              "name": "PrettyPrint",
              "optional": "False",
              "type": "Boolean"
            }
          ],
          "returnType": "String",
          "type": "Function"
        }
      ],
      "name": "JSONParser",
      "namespace": "JsonVSE",
      "properties": [
        {
          "default": "LIT_STR(\"1.0.2\")",
          "description": "",
          "name": "VSEVersion",
          "type": "String"
        }
      ]
    }
  ],
  "description": "Implement with UseVSE \"*JsonVSE\"",
  "name": "JsonVSE"
}
